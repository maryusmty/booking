<?php require 'db.php'; ?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<?php
$count_query = "SELECT COUNT(*) FROM bookings WHERE status = 1";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_active_bookings = $count_query_run->fetchColumn();


$count_query = "SELECT COUNT(*) FROM bookings WHERE status = 0";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_new_bookings = $count_query_run->fetchColumn();

$count_query = "SELECT COUNT(*) FROM rooms WHERE status = 1";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_active_rooms = $count_query_run->fetchColumn();

$count_total_query = "SELECT COUNT(*) FROM rooms";
$count_total_query_run = $conn->prepare($count_total_query);
$count_total_query_run->execute();
$count_total_rooms = $count_total_query_run->fetchColumn();  



//script calculare recenzii
$query = "SELECT COUNT(*) as total_reviews, AVG(stele_recenzie) as average_rating FROM ratings";
$query_run = $conn->prepare($query);
$query_run->execute();
$result = $query_run->fetch(PDO::FETCH_ASSOC);

$total_reviews = $result['total_reviews'];
$average_rating = round($result['average_rating'], 1);


$rating_message = "";
$badge_class = "";
if ($average_rating >= 4.5) {
    $rating_message = "Excelent";
    $badge_class = "bg-success";
} elseif ($average_rating >= 4.0) {
    $rating_message = "Foarte bune";
    $badge_class = "bg-success";
} elseif ($average_rating >= 3.0) {
    $rating_message = "Medii";
    $badge_class = "bg-warning";
} else {
    $rating_message = "Rele";
    $badge_class = "bg-danger";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<style>
    .card-body {
        padding: 20px;
    }
    .card h6 {
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
    }
    .card h2 {
        font-size: 1.75rem;
        font-weight: bold;
    }
    .card i {
        font-size: 2rem;
    }
</style>
<body>

<?php include('inc/sidebar.php') ?>
<?php include('inc/header.php') ?>
<?php

if (isset($_SESSION['message'])) {
    echo "<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
        }
    });
    Toast.fire({
        icon: 'success',
        title: '" . $_SESSION['message'] . "'
    });
    </script>";
    unset($_SESSION['message']); 
}

?>
<div class="main-content">
    <h2>Panoul de administrare - Rasfatul RelaxSarii</h2>
    <p>Selectati o optiune din meniul din stanga pentru a incepe.</p>
    <div class="row">
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-uppercase text-muted mb-1">Camere</h6>
                    <h2 class="mb-0"><?php echo $count_active_rooms . "/" . $count_total_rooms . " Camere"; ?></h2>
                    <h6 class="text-muted">Verifica disponibilitatea camerelor</h6>
                </div>
                <i class="fas fa-door-closed text-danger fa-2x"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-uppercase text-muted mb-1">Rezervari</h6>
                    <h2 class="mb-0"><?php echo $count_active_bookings ?> Rezervari Active</h2>
                    <h6 class="<?php echo ($count_new_bookings > 0) ? 'text-danger font-weight-bold' : 'text-muted'; ?>">
                        <?php echo $count_new_bookings; ?> Rezervari noi
                    </h6>
                </div>
                <i class="fas fa-calendar-check text-success fa-2x"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-uppercase text-muted mb-1">Recenzii Clienti</h6>
                    <h2 class="mb-0"><?php echo $average_rating; ?>/5 Rating</h2>
                    <h6 class="text-muted">Total: <?php echo $total_reviews; ?> recenzii</h6>
                </div>
                <i class="fas fa-star text-warning fa-2x"></i>
            </div>
        </div>
    </div>
</div>

</div>

<?php include('inc/footer.php') ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
