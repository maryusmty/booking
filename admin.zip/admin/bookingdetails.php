<?php require 'db.php'; ?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    $query = "SELECT * FROM bookings WHERE id = ?";
    $query_run = $conn->prepare($query);
    $query_run->execute([$id]);

    if($query_run->rowCount() > 0){
        $row = $query_run->fetch();

        $bookingName = $row['nume_client'];
        $bookingNotes = $row['notes'];
        $bookingPayment = $row['payment'];
        $Checkin = $row['checkin'];
        $Checkout = $row['checkout'];
        $bookingStatus = $row['status'];
        $bookingClientPhone = $row['phone'];
        $bookingClientMail = $row['mail'];
    } else {
        echo "Rezervarea nu a fost găsita.";
    }

    $bookingCheckin = date('d/m/Y', strtotime($Checkin));
    $bookingCheckout = date('d/m/Y', strtotime($Checkout));

} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

<?php include("inc/sidebar.php") ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <h2> Informatii Rezervare # <?php echo $id; ?></h2>
    <p></p>
    <hr>
    <?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title" id="booking-name">Optiuni rezervare</h5>
                <div>
                    <button class="btn btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#editBookingModal?<?php echo $id;?>" id="edit-button">Editare</button>
                    <button class="btn btn-danger btn-sm me-2" data-bs-toggle="modal" data-bs-target="#deleteBookingModal?<?php echo $id;?>" id="delete-button">Stergere</button>

                </div>
            </div>


            <div class="card-body">
            <p class="card-text">
            <strong>Status Rezervare:</strong>
            <?php
            if($bookingStatus == 0){
                        echo "<span class='badge bg-warning'>In asteptare</span>";
                        }else if($bookingStatus == 1){
                            echo "<span class='badge bg-success'>Confirmat, in viitor</span>";
                        }else if($bookingStatus == 2){
                            echo "<span class='badge bg-success'>Finalizat</span>";
                        }
                        else if($bookingStatus == 3){
                          echo "<span class='badge bg-danger'>Anulat</span>";
                      }
            ?></p>

                <p class="card-text" id="bookingPayment"><strong>Informatii privind plata:</strong> 
                <?php 
                        if($bookingPayment == 0){
                            echo "<span class='badge bg-danger'>Neachitat</span>";
                        }else if($bookingPayment == 1){
                            echo "<span class='badge bg-warning'>Avans achitat</span>";
                        }else if($bookingPayment == 2){
                            echo "<span class='badge bg-success'>Plata completa</span>";
                        }
                        ?></p>
                <p class="card-text"><strong>Nume client:</strong> <span id="bookingName"><?php echo htmlspecialchars($bookingName); ?> </span></p>
                <p class="card-text"><strong>Date contact client:</strong> <span id="bookingContact"> <?php echo '0'. htmlspecialchars($bookingClientPhone) . ' / ' . htmlspecialchars($bookingClientMail); ?></span></p>
                <p class="card-text"><strong>Check-in date:</strong> <span id="bookingCheckin"><?php echo htmlspecialchars($bookingCheckin); ?> </span></p>
                <p class="card-text"><strong>Check-out date:</strong> <span id="bookingCheckout"><?php echo htmlspecialchars($bookingCheckout); ?> </span></p>
                <p class="card-text" id="bookingNotes"><strong>Informatii suplimentare rezervare:</strong> <?php echo htmlspecialchars($bookingNotes); ?></p>

            </div>
        </div>
    </div>

   
</div>

<?php include("inc/footer.php") ?>



<!-- Modal pentru editarea unei rezervari -->
<div class="modal fade" id="editBookingModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="editBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editBookingModalLabel">Editeaza rezervarea</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action= "functions/booking_edit.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="mb-3">
              <label for="editBookingName" class="form-label">Nume client:</label>
              <input type="text" class="form-control" id="editBookingName" name="editBookingName" value="<?php echo $bookingName ?>" required>
            </div>
            <div class="mb-3">
                <label for="editbookingClientPhone" class="form-label">Numar de telefon client:</label> 
                <input type="number" class="form-control" id="editbookingClientPhone" name="editbookingClientPhone" required value="<?php echo $bookingClientPhone ?>">
            </div>
            <div class="mb-3">
                <label for="editbookingClientMail" class="form-label">Email client:</label> 
                <input type="maiil" class="form-control" id="editbookingClientMail" name="editbookingClientMail" required value="<?php echo $bookingClientMail ?>">
            </div>
            <div class="mb-3">
              <label for="editBookingCheckin">Check in:</label>
              <input type="date" class="form-control" id="editBookingCheckin" name="editBookingCheckin" <?php 
             $editCheckin = date('Y-m-d', strtotime($Checkin)); 
             echo 'value ="'.$editCheckin.'"';
             ?> required>
             
              <label for="editBookingCheckout">Check out:</label>
              <input type="date" class="form-control" id="editBookingCheckout" name="editBookingCheckout" <?php 
             $editCheckout = date('Y-m-d', strtotime($Checkout)); 
             echo 'value ="'.$editCheckout.'"';
             ?> required>
            </div>
            <div class="mb-3">
                <label for="bookingStatus" class="form-label">Status rezervare:</label>
                <div>
                    <input type="radio" id="bookingStatus0" name="bookingStatus" value="0" <?php if($bookingStatus == 0){echo 'checked';} ?>>
                    <label for="bookingStatus0">In asteptare</label>
                </div>
                <div>
                    <input type="radio" id="bookingStatus1" name="bookingStatus" value="1" <?php if($bookingStatus == 1){echo 'checked';} ?>>
                    <label for="bookingStatus1">Confirmat, in viitor</label>
                </div>
                <div>
                    <input type="radio" id="bookingStatus2" name="bookingStatus" value="2" <?php if($bookingStatus == 2){echo 'checked';} ?>>
                    <label for="bookingStatus2">Finalizat</label>
                </div>
                <div>
                    <input type="radio" id="bookingStatus3" name="bookingStatus" value="3" <?php if($bookingStatus == 3){echo 'checked';} ?>>
                    <label for="bookingStatus3">Anulat</label>
                </div>
            </div>

            <div class="mb-3">
                <label for="status_payment" class="form-label">Status plata:</label>
                <div>
                    <input type="radio" id="status_payment_0" name="status_payment" value="0" <?php if($bookingPayment == 0){echo 'checked';} ?>>
                    <label for="status_payment_0">Neachitat</label>
                </div>
                <div>
                    <input type="radio" id="status_payment_1" name="status_payment" value="1" <?php if($bookingPayment == 1){echo 'checked';} ?>>
                    <label for="status_payment_1">Avans achitat</label>
                </div>
                <div>
                    <input type="radio" id="status_payment_2" name="status_payment" value="2" <?php if($bookingPayment == 2){echo 'checked';} ?>>
                    <label for="status_payment_2">Plata completa</label>
                </div>
            </div>

            <div class="mb-3">
              <label for="editBookingNotes" class="form-label">Informatii suplimentare:</label>
              <textarea class="form-control" id="editBookingNotes" name="editBookingNotes" rows="3" required"><?php echo $bookingNotes ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary" name="edit_booking">Editeaza rezervarea</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <!-- Modal pentru stergerea unei rezervari -->
<div class="modal fade" id="deleteBookingModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="deleteBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteBookingModalLabel">Sterge rezervarea</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action= "functions/booking_delete.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="mb-3">
             <h6>Sunteti sigur ca doriti sa stergeti <b> Rezervarea # <?php echo $id;?></b></h6>
            </div>
            <button type="submit" class="btn btn-danger" name="sterge_booking">Da, sterge</button>
          </form>
        </div>
      </div>
    </div>
  </div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src= "script/main.js"></script>
</body>
</html>