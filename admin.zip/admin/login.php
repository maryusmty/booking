<?php
session_start();
require 'db.php';

if (isset($_POST['login_btn'])) {
    $login_input = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = :login_input OR email = :login_input LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':login_input', $login_input);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['adminLevel'] = $user['admin'];

        $update_query = "UPDATE users SET status = 1 WHERE id = :user_id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bindParam(':user_id', $user['id']);
        $update_stmt->execute();

        $_SESSION["message"] = "Logarea a fost efectuata cu succes!";
        header("Location: index.php");
        exit(0);
    } else {
        $_SESSION["error"] = "Nume de utilizator sau parola incorecta.";
        header("Location: login.php");  
        exit(0);
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rasfatul RelaxSarii</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            background-color: #f7f7f7;
            font-family: 'Arial', sans-serif;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #343a40;
            color: white;
            text-align: center;
            font-size: 24px;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .card-body {
            padding: 2rem;
        }
        .btn-dark {
            background-color: #343a40;
            border: none;
            border-radius: 5px;
            padding: 0.5rem 1.5rem;
            transition: background-color 0.3s ease;
        }
        .btn-dark:hover {
            background-color: #23272b;
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 5px;
            padding: 0.75rem;
            border: 1px solid #ced4da;
        }
        .alert {
            font-size: 0.9rem;
        }
        img {
            max-width: 50%;
            height: auto;
            margin-bottom: 1rem;
        }
        html, body {
    height: 100%;
}

body {
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1;
}

.footer {
    flex-shrink: 0;
    width: 100%;
}
    </style>
</head>
<body>
    <?php
    if (isset($_SESSION['error'])) {
        echo "<script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });
        Toast.fire({
            icon: 'error',
            title: '" . $_SESSION['error'] . "'
        });
        </script>";
        unset($_SESSION['error']); 
    }
    
    ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="card mt-5">
                <center><img src="images/image2.png" alt="Image not found"></center>
                <div class="card-header">Login</div>
                <div class="card-body">
                    <form action="login.php" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Nume utilizator sau Email</label>
                            <input type="text" name="username" id="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Parola</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <button type="submit" name="login_btn" class="btn btn-dark w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="footer mt-auto py-3 bg-dark text-white">
    <div class="container text-center">
        <p class="small mb-0">Panou de administrare &copy; 2024 Rasfatul RelaxSarii. <br>Toate drepturile rezervate.</p>
    </div>
</footer>
</body>
</html>
