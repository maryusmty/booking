// Script pentru packeges.php -> set status 
var checkboxPackeges = document.getElementById("status_check");
var inputPackeges = document.getElementById("status_pachet");

if (checkboxPackeges && inputPackeges) {
    checkboxPackeges.addEventListener('change', function() {
        if (checkboxPackeges.checked) {
            inputPackeges.value = '1';
        } else {
            inputPackeges.value = '0';
        }
    });
}
// -> end script

// Script pentru rating.php -> set status 
var checkboxRating = document.getElementById("status_check_rating");
var inputRating = document.getElementById("ratingStatus");

if (checkboxRating && inputRating) {
    checkboxRating.addEventListener('change', function() {
        if (checkboxRating.checked) {
            inputRating.value = '1';
        } else {
            inputRating.value = '0';
        }
    });
}
// -> end script
