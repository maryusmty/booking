const showLoginAlert = document.getElementById("login-alert");

showLoginAlert.addEventListener("click", (event) =>{
    event.preventDefault();
    const Toast = Swal.mixin({
        toast: true,
        position: "bottom-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.onmouseenter = Swal.stopTimer;
          toast.onmouseleave = Swal.resumeTimer;
        }
      });
      Toast.fire({
        icon: "success",
        title: "Logarea a fost efectuata cu succes!"
      });
})

