<?php
session_start();
require '../db.php'; // Include conexiunea PDO la baza de date
require 'invoice_functions.php'; // Include funcțiile reutilizabile

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

// Verifică dacă toate datele necesare sunt transmise prin POST
if (!isset($_POST['pension_name'], $_POST['pension_address'], $_POST['client_name'], $_POST['client_address'], $_POST['client_phone'], $_POST['client_email'], $_POST['service_description'], $_POST['service_quantity'], $_POST['service_unit_price'])) {
    header("Location: ../manage_invoices.php");
    exit(0);
}

// Preia datele din formular
$pension_name = $_POST['pension_name'];
$pension_address = $_POST['pension_address'];
$client_name = $_POST['client_name'];
$client_address = $_POST['client_address'];
$client_phone = $_POST['client_phone'];
$client_email = $_POST['client_email'];
$service_descriptions = $_POST['service_description'];
$service_quantities = $_POST['service_quantity'];
$service_unit_prices = $_POST['service_unit_price'];

$pension_phone = "07xx xxx xxx";
$pension_email = "office@rasfatulrelaxsarii.ro";

// Obține datele firmei, dacă există
$is_company = isset($_POST['is_company']) ? 1 : 0;
$company_name = $is_company ? $_POST['company_name'] : null;
$company_cui = $is_company ? $_POST['company_cui'] : null;
$client_address = $_POST['client_address'];
$company_bank = $is_company ? $_POST['company_bank'] : null;
$company_iban = $is_company ? $_POST['company_iban'] : null;

// Obține ID-ul clientului (sau îl adaugă în baza de date dacă nu există)
$client_id = get_client_id($conn, $client_name, $client_address, $client_phone, $client_email, $is_company, $company_name, $company_cui, $company_bank, $company_iban);


// Calculează subtotalul, TVA-ul și totalul facturii
$include_vat = isset($_POST['include_vat']) && $_POST['include_vat'] == 'on';
$totals = calculate_totals($service_descriptions, $service_quantities, $service_unit_prices, $include_vat);
$data = $totals['data'];
$subtotal = $totals['subtotal'];
$tva = $totals['tva'];
$total = $totals['total'];

// Salvează factura în baza de date
$invoice_id = save_invoice($conn, $client_id, $total);

// Inserare articole factură în baza de date
try {
    foreach ($service_descriptions as $index => $description) {
        $quantity = $service_quantities[$index];
        $unit_price = $service_unit_prices[$index];
        $total_price = $quantity * $unit_price;

        $stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total_price) VALUES (:invoice_id, :description, :quantity, :unit_price, :total_price)");
        $stmt->execute([
            ':invoice_id' => $invoice_id,
            ':description' => $description,
            ':quantity' => $quantity,
            ':unit_price' => $unit_price,
            ':total_price' => $total_price
        ]);
    }
} catch (PDOException $e) {
    echo "Eroare la inserarea articolelor: " . $e->getMessage();
    exit;
}

// Generare PDF
$pdf = generate_invoice_pdf($invoice_id, $pension_name, $pension_address, $pension_phone, $pension_email, $client_name, $client_address, $client_phone, $client_email, $data, $subtotal, $tva, $total, $is_company, $company_name, $company_cui, $company_bank, $company_iban);

// Exportă PDF-ul
$pdf->Output('D', 'factura_' . $invoice_id . '.pdf');

// După generare, redirecționează la pagina de gestionare a facturilor
header("Location: ../manage_invoices.php");
exit;
?>
