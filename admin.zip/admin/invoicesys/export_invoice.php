<?php
session_start();
require '../db.php';
require 'invoice_functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

if (!isset($_GET['id'])) {
    header("Location: manage_invoices.php");
    exit(0);
}

$invoice_id = $_GET['id'];

// Preluare detalii factură
$invoice = get_invoice_details($conn, $invoice_id);
$invoice_items = get_invoice_items($conn, $invoice_id);

if (!$invoice) {
    header("Location: manage_invoices.php");
    exit(0);
}

// Generare PDF
$pdf = generate_invoice_pdf(
    $invoice_id,
    $invoice['pension_name'],
    $invoice['pension_address'],
    $invoice['pension_phone'],
    $invoice['pension_email'],
    $invoice['name'],
    $invoice['address'],
    $invoice['phone'],
    $invoice['email'],
    $invoice_items,
    $invoice['subtotal'],
    $invoice['tva'],
    $invoice['total']
);

// Exportă PDF-ul
$pdf->Output('D', 'factura_' . $invoice_id . '.pdf');
$_SESSION['message'] = "Ai exportat factura in format PDF!";
exit;
?>
