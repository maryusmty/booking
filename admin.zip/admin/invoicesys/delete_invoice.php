<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

if (!isset($_POST['id'])) {
    header("Location: ../manage_invoices.php");
    exit(0);
}

$invoice_id = $_POST['id'];

// Ștergere factură și articolele asociate
$stmt = $conn->prepare("DELETE FROM invoice_items WHERE invoice_id = :invoice_id");
$stmt->execute([':invoice_id' => $invoice_id]);

$stmt = $conn->prepare("DELETE FROM invoices WHERE id = :invoice_id");
$stmt->execute([':invoice_id' => $invoice_id]);

$_SESSION['message'] = "Ai șters o factură cu succes!";
header("Location: ../manage_invoices.php");
exit(0);
?>
