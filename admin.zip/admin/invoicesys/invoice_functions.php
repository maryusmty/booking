<?php
require_once('fpdf.php');
require_once('PDF_Invoice.php');


function get_invoice_details($conn, $invoice_id) {
    $query = "SELECT invoices.id, clients.name, clients.address, clients.phone, clients.email, invoices.date, invoices.total, invoices.status, 
                     'Rasfatul RelaxSarii' as pension_name, 
                     'Provita de jos, Jud. Prahova' as pension_address, 
                     '07xx xxx xxx' as pension_phone, 
                     'office@rasfatulrelaxsarii.ro' as pension_email,
                     (invoices.total / 1.19) as subtotal,
                     (invoices.total - (invoices.total / 1.19)) as tva
              FROM invoices 
              JOIN clients ON invoices.client_id = clients.id 
              WHERE invoices.id = :invoice_id";
    $stmt = $conn->prepare($query);
    $stmt->execute([':invoice_id' => $invoice_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function get_invoice_items($conn, $invoice_id) {
    $query_items = "SELECT description, quantity, unit_price, total_price 
                    FROM invoice_items 
                    WHERE invoice_id = :invoice_id";
    $stmt_items = $conn->prepare($query_items);
    $stmt_items->execute([':invoice_id' => $invoice_id]);
    return $stmt_items->fetchAll(PDO::FETCH_ASSOC);
}

function get_client_id($conn, $client_name, $client_address, $client_phone, $client_email, $is_company = false, $company_name = null, $company_cui = null, $company_bank = null, $company_iban = null) {
    // Căutăm clientul în funcție de tipul său
    if ($is_company) {
        // Dacă este firmă, verificăm după CUI (Codul unic de identificare)
        $stmt = $conn->prepare("SELECT id FROM clients WHERE company_cui = :company_cui");
        $stmt->execute([
            ':company_cui' => $company_cui
        ]);
    } else {
        // Dacă este persoană fizică, verificăm după nume, adresă și email
        $stmt = $conn->prepare("SELECT id FROM clients WHERE name = :name AND address = :address AND email = :email");
        $stmt->execute([
            ':name' => $client_name,
            ':address' => $client_address,
            ':email' => $client_email
        ]);
    }

    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    // Dacă clientul există, returnăm ID-ul său
    if ($client) {
        return $client['id'];
    } else {
        // Dacă clientul nu există, îl adăugăm în baza de date
        if ($is_company) {
            // Inserăm o firmă
            $stmt = $conn->prepare("INSERT INTO clients (name, address, phone, email, is_company, company_name, company_cui, company_bank, company_iban) 
                                     VALUES (:name, :address, :phone, :email, :is_company, :company_name, :company_cui, :company_bank, :company_iban)");
            $stmt->execute([
                ':name' => $client_name,
                ':address' => $client_address,
                ':phone' => $client_phone,
                ':email' => $client_email,
                ':is_company' => $is_company,
                ':company_name' => $company_name,
                ':company_cui' => $company_cui,
                ':company_bank' => $company_bank,
                ':company_iban' => $company_iban
            ]);
        } else {
            // Inserăm o persoană fizică
            $stmt = $conn->prepare("INSERT INTO clients (name, address, phone, email, is_company) 
                                     VALUES (:name, :address, :phone, :email, 0)");
            $stmt->execute([
                ':name' => $client_name,
                ':address' => $client_address,
                ':phone' => $client_phone,
                ':email' => $client_email
            ]);
        }

        // Returnăm ID-ul noului client
        return $conn->lastInsertId(); 
    }
}





function calculate_totals($service_descriptions, $service_quantities, $service_unit_prices, $include_vat) {
    $subtotal = 0;
    $data = [];

    for ($i = 0; $i < count($service_descriptions); $i++) {
        $description = $service_descriptions[$i];
        $quantity = $service_quantities[$i];
        $unit_price = $service_unit_prices[$i];
        $total_price = $quantity * $unit_price;

        $data[] = array($description, $quantity, number_format($unit_price, 2) . ' RON', number_format($total_price, 2) . ' RON');
        $subtotal += $total_price;
    }

    // Aplică TVA dacă este cazul
    $tva = $include_vat ? $subtotal * 0.19 : 0;
    $total = $subtotal + $tva;

    return ['data' => $data, 'subtotal' => $subtotal, 'tva' => $tva, 'total' => $total];
}

function save_invoice($conn, $client_id, $total) {
    $stmt = $conn->prepare("INSERT INTO invoices (client_id, date, total) 
                            VALUES (:client_id, NOW(), :total)");
    $stmt->execute([
        ':client_id' => $client_id,
        ':total' => $total
    ]);

    return $conn->lastInsertId();
}


function generate_invoice_pdf($invoice_id, $pension_name, $pension_address, $pension_phone, $pension_email, $client_name, $client_address, $client_phone, $client_email, $data, $subtotal, $tva, $total, $is_company, $company_name = null, $company_cui = null, $company_bank = null, $company_iban = null) {
    $pdf = new PDF_Invoice();
    $pdf->AliasNbPages();
    $pdf->AddPage();

    // Adăugare logo și titlu
    $pdf->Image('../images/invoice_image.png', 10, 10, 30); 
    $pdf->SetFont('Arial', 'B', 20);
    $pdf->Cell(0, 10, 'FACTURA', 0, 1, 'C');

    // Date factură (colțul dreapta sus)
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 7, "Referinta: " . $invoice_id, 0, 1, 'R');
    $pdf->Cell(0, 7, "Creata la: " . date('d/m/Y'), 0, 1, 'R');
    $pdf->Cell(0, 7, "Pana la: " . date('d/m/Y', strtotime('+7 days')), 0, 1, 'R');
    $pdf->Ln(10);

    // Informații Pensiune și Client
    $pdf->SetFont('Arial', '', 12);

    // Datele pensiunii
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(95, 5, 'DATE PENSIUNE:', 0, 0, 'L');
    $pdf->SetX(105);
    $pdf->Cell(95, 5, $is_company ? 'DATE FIRMA:' : 'DATE CLIENT:', 0, 1, 'R');

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(95, 5, $pension_name, 0, 0, 'L');
    if ($is_company) {
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "Denumire Firma: " . $company_name, 0, 1, 'R');
        $pdf->Cell(95, 5, $pension_address, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "CUI: " . $company_cui, 0, 1, 'R');
        $pdf->Cell(95, 5, "Telefon: " . $pension_phone, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "Adresa Sediu Social: " . $client_address, 0, 1, 'R');  // Adresa corectă
        $pdf->Cell(95, 5, "Email: " . $pension_email, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "Banca: " . $company_bank, 0, 1, 'R');  // Numele băncii
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "IBAN: " . $company_iban, 0, 1, 'R');   // Codul IBAN
    } else {
        $pdf->SetX(105);
        $pdf->Cell(95, 5, $client_name, 0, 1, 'R');
        $pdf->Cell(95, 5, $pension_address, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, $client_address, 0, 1, 'R');
        $pdf->Cell(95, 5, "Telefon: " . $pension_phone, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "Telefon: " . $client_phone, 0, 1, 'R');
        $pdf->Cell(95, 5, "Email: " . $pension_email, 0, 0, 'L');
        $pdf->SetX(105);
        $pdf->Cell(95, 5, "Email: " . $client_email, 0, 1, 'R');
    }

    $pdf->Ln(10);

    // Datele facturii (tabel)
    $header = array('Produs', 'Cantitate', 'Pret unitar (RON)', 'Total (RON)');
    $pdf->addInvoiceTable($header, $data);

    // Afișează subtotal, TVA și total
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(130, 7, '', 0, 0);
    $pdf->Cell(30, 7, 'Subtotal:', 0, 0, 'R');
    $pdf->Cell(30, 7, number_format($subtotal, 2) . ' RON', 0, 1, 'R');
    $pdf->Cell(130, 7, '', 0, 0);
    $pdf->Cell(30, 7, 'TVA (19%):', 0, 0, 'R');
    $pdf->Cell(30, 7, number_format($tva, 2) . ' RON', 0, 1, 'R');
    $pdf->Cell(130, 7, '', 0, 0);
    $pdf->Cell(30, 7, 'Total:', 0, 0, 'R');
    $pdf->Cell(30, 7, number_format($total, 2) . ' RON', 0, 1, 'R');

    return $pdf;
}



