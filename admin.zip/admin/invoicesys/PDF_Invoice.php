<?php
require_once('fpdf.php'); // Include fișierul FPDF original

// Extinde clasa FPDF
class PDF_Invoice extends FPDF {

    // Metoda pentru footer-ul facturii
    function footer() {
        // Poziționarea la 1.5 cm de jos
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }

    // Metoda pentru detaliile pensiunii
    function addPensionDetails($pensionName, $pensionAddress, $invoiceDate) {
        $this->SetFont('Arial','B',12);
        $this->Cell(100,10,"Pensiune: $pensionName",0,1);
        $this->SetFont('Arial','',12);
        $this->Cell(100,10,$pensionAddress,0,1);
        $this->Ln(5);
        $this->Cell(100,10,"Data facturii: $invoiceDate",0,1);
        $this->Ln(10);
    }

    // Metoda pentru detaliile clientului
    function addClientDetails($clientName, $clientAddress) {
        $this->SetFont('Arial','B',12);
        $this->Cell(100,10,"Client: $clientName",0,1);
        $this->SetFont('Arial','',12);
        $this->Cell(100,10,$clientAddress,0,1);
        $this->Ln(10);
    }

    // Metoda pentru tabelul facturii
    function addInvoiceTable($header, $data) {
        // Culori pentru header
        $this->SetFillColor(200,220,255);
        $this->SetDrawColor(50,50,100);
        $this->SetFont('Arial','B',12);
        foreach($header as $col)
            $this->Cell(47,7,$col,1,0,'C',true);
        $this->Ln();
        
        // Datele din tabel
        $this->SetFont('Arial','',12);
        foreach($data as $row) {
            foreach($row as $col)
                $this->Cell(47,6,$col,1);
            $this->Ln();
        }
        $this->Ln(10);
    }

    // Metoda pentru totalul facturii
    function addTotal($total) {
        $this->SetFont('Arial','B',12);
        $this->Cell(141,10,'Total:',1,0,'R');
        $this->Cell(47,10,$total.' RON',1,1,'C');
    }
}
?>
