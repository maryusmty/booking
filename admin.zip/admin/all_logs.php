<?php require 'db.php'; ?>
<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['adminLevel'] <= 0) {
    header("Location: login.php");
    exit(0);
}

// Pagination and Search
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$logs_per_page = 25;
$offset = ($page - 1) * $logs_per_page;

$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_sql = '';
if ($search_term) {
    $search_sql = "WHERE users.username LIKE :search_term OR user_logs.action LIKE :search_term";
}


$total_logs_query = "SELECT COUNT(*) FROM user_logs LEFT JOIN users ON user_logs.user_id = users.id $search_sql";
$total_logs_stmt = $conn->prepare($total_logs_query);
if ($search_term) {
    $total_logs_stmt->bindValue(':search_term', '%' . $search_term . '%', PDO::PARAM_STR);
}
$total_logs_stmt->execute();
$total_logs = $total_logs_stmt->fetchColumn();


$logs_query = "
    SELECT user_logs.id, user_logs.action, user_logs.timestamp, users.username 
    FROM user_logs 
    LEFT JOIN users ON user_logs.user_id = users.id 
    $search_sql
    ORDER BY user_logs.timestamp DESC 
    LIMIT :logs_per_page OFFSET :offset";
$logs_query_run = $conn->prepare($logs_query);

if ($search_term) {
    $logs_query_run->bindValue(':search_term', '%' . $search_term . '%', PDO::PARAM_STR);
}
$logs_query_run->bindValue(':logs_per_page', $logs_per_page, PDO::PARAM_INT);
$logs_query_run->bindValue(':offset', $offset, PDO::PARAM_INT);
$logs_query_run->execute();
$all_logs = $logs_query_run->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

<?php include('inc/sidebar.php'); ?>
<?php include('inc/header.php'); ?>

<div class="main-content">
    <h3>Toate log-urile de pe platforma</h3>
    <hr>

    <!-- Search Form -->
    <form method="GET" action="" class="mb-3 col-sm-4">
        <div class="input-group ">
            <input type="text" name="search" class="form-control" placeholder="Căutare log-uri..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button class="btn btn-dark" type="submit" style="z-index: 0;">Caută</button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID Log</th>
                    <th>Utilizator</th>
                    <th>Acțiune</th>
                    <th>Data și ora</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($all_logs) > 0): ?>
                    <?php foreach ($all_logs as $log): ?>
                        <tr>
                            <td><?php echo $log['id']; ?></td>
                            <td><?php echo htmlspecialchars($log['username']); ?></td>
                            <td><?php echo htmlspecialchars($log['action']); ?></td>
                            <td><?php echo $log['timestamp']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">Nu există log-uri.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php
    $total_pages = ceil($total_logs / $logs_per_page);

    if ($total_pages > 1): ?>
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_term); ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php if ($page == $i) echo 'active'; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_term); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php if ($page >= $total_pages) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_term); ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<?php include('inc/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
