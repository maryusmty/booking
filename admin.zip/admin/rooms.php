<?php
require 'db.php';
?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<style>
    .upload-placeholder {
        width: 100%;
        height: 188px;
        background-color: #e9ecef;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        text-align: center;
    }

    .upload-placeholder input[type="file"] {
        display: none;
    }

    .title-input {
        border: none;
        border-bottom: 1px solid #ced4da;
        width: 100%;
        font-size: 1.25rem;
        margin-bottom: 10px;
    }

    .title-input::placeholder {
        color: #6c757d;
        font-weight: bold;
    }

    .title-input:focus {
        outline: none;
        border-bottom: 1px solid #007bff;
    }

    .status-badge {
        cursor: pointer;
        margin-right: 10px;
    }

    .status-badge.active {
        border: 2px solid #000;
    }
    input[name="facilityName"] {
    border: none;
    outline: none; /* Elimină bordura care apare când inputul este focusat */
    background-color: transparent; /* Asigură-te că fundalul este transparent */
    font-size: 1rem; /* Ajustează dimensiunea fontului după nevoie */
    padding: 0; /* Elimină paddingul implicit */
    width: auto; /* Permite inputului să se redimensioneze în funcție de conținut */
    color: inherit; /* Preia culoarea textului din container */
}

    input[name="facilityName"]::placeholder {
        color: #6c757d; /* Ajustează culoarea placeholderului */
        font-style: italic; /* Face placeholderul să fie mai distinct */
    }
</style>
<body>
<?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>
<?php include('inc/sidebar.php') ?>
<?php include('inc/header.php') ?>


<div class="main-content">
    <h2>Camere si Facilitati</h2>
    <hr>

    
    <?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: '" . $_SESSION['icon'] . "',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>

    <div class="row">
        
    <div class='col-sm-3 mb-3'>
    <div class='card'>
        <form action="functions/room_create.php" method="POST" enctype="multipart/form-data">
            <div class='upload-placeholder' onclick="document.getElementById('roomImages').click();">
                <span id="uploadText">Apasa pentru a adauga imagini.</span>
                <input type="file" id="roomImages" name="roomImages[]" multiple required onchange="updateUploadText()">
            </div>
            <div class='card-body'>
                <input type="text" class="title-input" id="roomName" name="roomName" placeholder="Titlu camera" required>

                <div class="mb-3">
                    <input type="number" class="form-control" id="roomCapacity" name="roomCapacity" placeholder="Capacitate camera" required>
                </div>

                <div class="mb-3">
                    <input type="number" class="form-control" id="roomPriceWeek" name="roomPriceWeek" placeholder="Preț pe noapte (săptămână)" required>
                </div>

                <div class="mb-3">
                    <input type="number" class="form-control" id="roomPriceWeekend" name="roomPriceWeekend" placeholder="Preț pe noapte (weekend)" required>
                </div>

                <div class="status-options mb-3">
                    <input type="hidden" id="roomStatus" name="roomStatus" value="0">
                    <span id="status-0" class="badge bg-danger status-badge active" onclick="selectStatus(0)">Nelistata</span>
                    <span id="status-1" class="badge bg-success status-badge" onclick="selectStatus(1)">Listata</span>
                    <span id="status-2" class="badge bg-warning text-dark status-badge" onclick="selectStatus(2)">Mentenanta</span>
                </div>

                <button type="submit" class="btn btn-sm btn-primary" name="submit_room" style="width: 100%;">Adaugă camera</button>
            </div>
        </form>
    </div>
</div>
    
    <?php 
    $carduriPePagina = 3;

    $count_query = "SELECT COUNT(*) as id FROM rooms";
    $count_query_run = $conn->prepare($count_query);
    $count_query_run->execute();
    $count_result = $count_query_run->fetchColumn();
    
    $totalCarduri = $count_result;
    
    $totalPagini = ceil($totalCarduri / $carduriPePagina);
    
    if (!isset ($_GET['pagina']) ) {  
        $paginaCurenta  = 1;  
    } else {  
        $paginaCurenta = $_GET['pagina'];  
    }  
    $limita = ($paginaCurenta - 1) * $carduriPePagina;
    $offset = $carduriPePagina;
    

    $query = "SELECT * FROM rooms ORDER BY id DESC LIMIT :limita, :offset";
    $query_run = $conn->prepare($query);
    $query_run->bindParam(':limita', $limita, PDO::PARAM_INT);
    $query_run->bindParam(':offset', $offset, PDO::PARAM_INT);
    $query_run->execute();

    if ($query_run->rowCount() > 0) { 
        while ($row = $query_run->fetch(PDO::FETCH_ASSOC)) { 
            $id = $row['id'];
            $roomName = $row['nume_camera'];
            $roomImages = json_decode($row['imagine'], true);
            $roomStatus = $row['status'];
            $roomCapacity = $row['capacitate_camera'];
            $roomNormalPrice = $row['pret_saptamana'];
            $roomWeekendPrice = $row['pret_weekend'];
    ?>


<div class='col-sm-3 mb-3'>
    <div class='card shadow-sm' style="border-radius: 10px;">
        <?php if (is_array($roomImages) && count($roomImages) > 0): ?>
            <div id="carouselRoom<?php echo $id; ?>" class="carousel slide" data-bs-interval="false">
                <div class="carousel-inner" style="border-radius: 10px 10px 0 0;">
                    <?php foreach ($roomImages as $index => $image): ?>
                        <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                            <img src="room_images/<?php echo htmlspecialchars($image); ?>" class="d-block w-100 img-fluid" alt="Imagine camera" style="max-height: 200px; object-fit: cover; border-radius: 10px 10px 0 0;">
                        </div>
                    <?php endforeach; ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselRoom<?php echo $id; ?>" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselRoom<?php echo $id; ?>" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

        <?php else: ?>
            <img src="placeholder-image.jpg" class="card-img-top" alt="Nicio imagine disponibilă" style="border-radius: 10px 10px 0 0;">
        <?php endif; ?>
        <div class='card-body'>
            <h5 class='card-title'><?php echo htmlspecialchars($roomName); ?></h5>
            <p class='card-text'>
                Status: 
                <?php 
                if ($roomStatus == 0) {
                    echo "<span class='badge bg-danger'>Nelistata</span>";
                } elseif ($roomStatus == 1) {
                    echo "<span class='badge bg-success'>Listata</span>";
                } elseif ($roomStatus == 2) {
                    echo "<span class='badge bg-warning text-dark'>Mentenanta</span>";
                }
                ?>
            </p>

            <!-- Afișarea capacității camerei -->
            <p class='card-text'>
                <i class="fas fa-users"></i> <?php echo htmlspecialchars($roomCapacity); ?> persoane
            </p>

            <?php
            // Determină ziua curentă
            $today = date('N'); // 'N' returnează ziua săptămânii în format numeric (1 pentru Luni, 7 pentru Duminică)
            // $today = 3;
            // Alege prețul în funcție de ziua săptămânii
            if ($today >= 6) { // Dacă este Sâmbătă (6) sau Duminică (7)
                $displayPrice = $roomWeekendPrice;
            } else { // În timpul săptămânii (Luni până Vineri)
                $displayPrice = $roomNormalPrice;
            }
            ?>

            <!-- Afișarea prețului camerei -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="badge bg-primary">
                <?php echo htmlspecialchars($displayPrice); ?> RON / noapte
                </span>
            </div>

            <a href='roomdetails.php?id=<?php echo $id; ?>' class='btn btn-sm btn-primary' style='width: 100%; border-radius: 5px;'>Vizualizeaza</a>
        </div>
    </div>
</div>

    <?php
        }
    } else {
        echo "<div class='col-12'><div class='alert alert-secondary text-center'>Nu există camere adaugate momentan.</div></div>";
    }
    ?>
</div>


         <?php
echo '<center>';
echo '<nav aria-label="Pagini">';
echo '<ul class="pagination justify-content-center">';
for ($p = 1; $p <= $totalPagini; $p++) {
    // Adaugă clasa "active" pentru pagina curentă
    if ($p == $paginaCurenta) {
        echo '<li class="page-item active" aria-current="page">';
    } else {
        echo '<li class="page-item">';
    }
    echo '<a class="page-link" href="rooms.php?pagina=' . $p . '">' . $p . '</a>';
    echo '</li>';
}
echo '</ul>';
echo '</nav>';
echo '</center>';
?>


<h2>Facilitati existente</h2>
<hr>
<div class="row">

    <!-- Card pentru adăugarea unei noi facilități -->
    <div class="col-auto">
        <div class="d-inline-flex align-items-center px-3 py-2 fw-semibold text-dark bg-light border border-dark rounded-pill">
            <form action="functions/facility_create.php" method="POST" class="d-inline-block">
                <input type="text" class="border-0 bg-light" name="facilityName" placeholder="Adauga o noua facilitate" required>
                <button type="submit" class="btn p-0 border-0 bg-transparent text-success ms-2" aria-label="Add" name="submit_facility">
                    <i class="fa-solid fa-plus"></i>
                </button>
            </form>
        </div>
    </div>

    <?php
    // Preluarea facilităților din baza de date
    $query = "SELECT * FROM facilitati";
    $query_run = $conn->prepare($query);
    $query_run->execute();

    if ($query_run->rowCount() > 0) {
        while ($row = $query_run->fetch(PDO::FETCH_ASSOC)) {
            $id = $row['id'];
            $facilityName = htmlspecialchars($row['denumire_facilitate']);
            ?>
            <div class="col-auto">
                <small class="d-inline-flex align-items-center px-3 py-2 fw-semibold text-dark bg-light border border-dark rounded-pill">
                    <?php echo htmlspecialchars($facilityName); ?>
                    <form action="functions/facility_delete.php" method="POST" class="d-inline-block float-end ms-2 mb-0">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <button type="submit" class="btn p-0 border-0 bg-transparent text-danger" aria-label="Delete" name="submit_facility_delete">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </small>
            </div>

            <?php
        }
    } 
    ?>
</div>

<?php include('inc/footer.php') ?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function selectStatus(status) {
        document.getElementById('roomStatus').value = status;
        
        // Remove active class from all badges
        document.querySelectorAll('.status-badge').forEach(function(badge) {
            badge.classList.remove('active');
        });
        
        // Add active class to the selected badge
        document.getElementById('status-' + status).classList.add('active');
    }
    function updateUploadText() {
        var input = document.getElementById('roomImages');
        var uploadText = document.getElementById('uploadText');
        var fileCount = input.files.length;

        if (fileCount === 1) {
            uploadText.innerText = "Ai selectat 1 fisier";
        } else if (fileCount > 1) {
            uploadText.innerText = "Ai selectat " + fileCount + " de fisiere";
        } else {
            uploadText.innerText = "Apasa pentru a adauga imagini.";
        }
    }
</script>

</body>
</html>
