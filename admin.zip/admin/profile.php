<?php require 'db.php'; ?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
} else {
    $user_id = $_SESSION['user_id']; 
}

// Utilizator selectat
$query = "SELECT * FROM users WHERE id = :user_id";
$query_run = $conn->prepare($query);
$query_run->execute(['user_id' => $user_id]);

if ($query_run->rowCount() > 0) {
    $user = $query_run->fetch();

    $username = $user['username'];
    $email = $user['email'];
    $admin = $user['admin'];
    $user_status = $user['status'];
} else {
    echo "Utilizatorul nu a fost găsit.";
    exit(0);
}

if ($user_id == $_SESSION['user_id'] && isset($_POST['update_profile'])) {
    $new_username = $_POST['username'];
    $new_email = $_POST['email'];
    $new_password = $_POST['password'];

    if (!empty($new_password)) {
        $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $update_query = "UPDATE users SET username = :username, email = :email, password = :password WHERE id = :user_id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->execute(['username' => $new_username, 'email' => $new_email, 'password' => $new_password_hashed, 'user_id' => $user_id]);
    } else {
        $update_query = "UPDATE users SET username = :username, email = :email WHERE id = :user_id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->execute(['username' => $new_username, 'email' => $new_email, 'user_id' => $user_id]);
    }

    $_SESSION['message'] = "Profilul a fost actualizat cu succes!";
    header("Location: profile.php?id=" . $user_id);
    exit(0);
}

    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
    $logs_per_page = 10;
    $offset = ($page - 1) * $logs_per_page;

    $search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
    $search_sql = '';
    if ($search_term) {
        $search_sql = "AND action LIKE :search_term";
    }

    $total_logs_query = "SELECT COUNT(*) FROM user_logs WHERE user_id = :user_id $search_sql";
    $total_logs_stmt = $conn->prepare($total_logs_query);
    $total_logs_params = ['user_id' => $user_id];
    if ($search_term) {
        $total_logs_params['search_term'] = '%' . $search_term . '%';
    }
    $total_logs_stmt->execute($total_logs_params);
    $total_logs = $total_logs_stmt->fetchColumn();

    $logs_query = "SELECT * FROM user_logs WHERE user_id = :user_id $search_sql ORDER BY timestamp DESC LIMIT :logs_per_page OFFSET :offset";
    $logs_query_run = $conn->prepare($logs_query);
    $logs_query_run->bindValue(':logs_per_page', $logs_per_page, PDO::PARAM_INT);
    $logs_query_run->bindValue(':offset', $offset, PDO::PARAM_INT);
    if ($search_term) {
        $logs_query_run->bindValue(':search_term', '%' . $search_term . '%', PDO::PARAM_STR);
    }
    $logs_query_run->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $logs_query_run->execute();
    $user_logs = $logs_query_run->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profilul utilizatorului <?php echo htmlspecialchars($username); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
</head>

<body>

<?php include('inc/sidebar.php'); ?>
<?php include('inc/header.php'); ?>

<div class="main-content">
    <div class="card">
        <?php
        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'profile';
        ?>
        <div class="card-header">
            <ul class="nav nav-pills card-header-pills">
                <li class="nav-item">
                    <a class="nav-link <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" id="profile-tab" data-bs-toggle="pill" href="#profile-content">Profil</a>
                </li>
                <?php if($_SESSION['adminLevel'] > 0): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $active_tab === 'logs' ? 'active' : ''; ?>" id="logs-tab" data-bs-toggle="pill" href="#logs-content">User Logs</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="card-body tab-content">
            <!-- Profil Content -->
            <div class="tab-pane fade <?php echo $active_tab === 'profile' ? 'show active' : ''; ?>" id="profile-content">
                <h3>Profilul utilizatorului <?php echo htmlspecialchars($username); ?></h3>
                <hr>

                <?php
                if (isset($_SESSION['message'])) {
                    echo "<script>
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.onmouseenter = Swal.stopTimer;
                            toast.onmouseleave = Swal.resumeTimer;
                        }
                    });
                    Toast.fire({
                        icon: 'success',
                        title: '" . $_SESSION['message'] . "'
                    });
                    </script>";
                    unset($_SESSION['message']); 
                }
                ?>

                <?php if ($user_id == $_SESSION['user_id']): ?>
                    <form action="profile.php?id=<?php echo $user_id; ?>" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Parola nouă (opțional):</label>
                            <input type="password" class="form-control" id="password" name="password">
                            <small class="form-text text-muted">Lasă acest câmp gol dacă nu dorești să schimbi parola.</small>
                        </div>

                        <button type="submit" class="btn btn-primary" name="update_profile">Actualizează Profilul</button>
                    </form>
                <?php else: ?>
                    <p><strong>Username: </strong> <?php echo htmlspecialchars($username); ?></p>
                    <p><strong>Email: </strong> <?php echo htmlspecialchars($email); ?></p>
                    <p><strong>Grad: </strong> 
                    <?php 
                        if($admin == 2){
                            echo '<span class="badge bg-developer">Developer</span>';
                        } else if($admin == 1){
                            echo '<span class="badge bg-danger">Administrator</span>';
                        } else {
                            echo '<span class="badge bg-secondary">Not administrator</span>';
                        }
                    ?>
                    </p>
                    <p><strong>Status: </strong> 
                    <?php 
                        if($user_status == 0){
                            echo '<span class="badge bg-danger">Offline</span>';
                        } else if($user_status == 1){
                            echo '<span class="badge bg-success">Online</span>';
                        }
                    ?>
                    </p>
                    <p class = "text-secondary">Acest profil aparține altui utilizator.</p>
                <?php endif; ?>
            </div>

            <?php if($_SESSION['adminLevel'] > 0): ?>
            <div class="tab-pane fade <?php echo $active_tab === 'logs' ? 'show active' : ''; ?>" id="logs-content">
                <h3>Log-uri ale utilizatorului <?php echo htmlspecialchars($username); ?></h3>
                <p>
                <i class="fa-solid fa-circle-info link-primary"></i> <a href="all_logs.php" class="text-primary">Verifică toate log-urile de pe platformă.</a>
                </p>
                <hr>

                <!-- Search Form -->
                <form method="GET" action="" class="mb-3 col-sm-4">
                    <input type="hidden" name="id" value="<?php echo $user_id; ?>">
                    <input type="hidden" name="tab" value="logs">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo "Cauta in log-urile lui $username..." ?>" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button class="btn btn-dark" type="submit" style="z-index: 0;">Caută</button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>ID Log</th>
                                <th>Acțiune</th>
                                <th>Data și ora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($user_logs) > 0): ?>
                                <?php foreach ($user_logs as $log): ?>
                                    <tr>
                                        <td><?php echo $log['id']; ?></td>
                                        <td><?php echo htmlspecialchars($log['action']); ?></td>
                                        <td><?php echo $log['timestamp']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3">Nu există log-uri pentru acest utilizator.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php
                $total_pages = ceil($total_logs / $logs_per_page);

                if ($total_pages > 1): ?>
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                            <a class="page-link" href="?id=<?php echo $user_id; ?>&page=<?php echo $page - 1; ?>&tab=logs&search=<?php echo urlencode($search_term); ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php if ($page == $i) echo 'active'; ?>">
                                <a class="page-link" href="?id=<?php echo $user_id; ?>&page=<?php echo $i; ?>&tab=logs&search=<?php echo urlencode($search_term); ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?php if ($page >= $total_pages) echo 'disabled'; ?>">
                            <a class="page-link" href="?id=<?php echo $user_id; ?>&page=<?php echo $page + 1; ?>&tab=logs&search=<?php echo urlencode($search_term); ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('inc/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
