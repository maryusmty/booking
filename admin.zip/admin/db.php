<?php
// Configurarea datelor de conectare
$host = 'localhost';
$db = 'rasfatul_relaxarii';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';


try{
    $conn = new PDO("mysql:host=$host;dbname=$db", $user,$pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "success!";
}catch(PDOException $e){
    echo 'Connection Fail' .$e->getMessage();
}


$pageTitle = "Panou de administrare - Răsfățul RelaxSării";
$webPageName = "Răsfățul RelaxSării";

date_default_timezone_set('Europe/Bucharest');


 ?>