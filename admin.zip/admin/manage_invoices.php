<?php
session_start();
require 'db.php'; // Include conexiunea PDO la baza de date

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

// Calculați numărul total de facturi
$total_invoices_query = "SELECT COUNT(*) FROM invoices";
$total_invoices = $conn->query($total_invoices_query)->fetchColumn();

// Calculați suma totală a facturilor achitate
$paid_amount_query = "SELECT SUM(total) FROM invoices WHERE status = 1";
$paid_amount = $conn->query($paid_amount_query)->fetchColumn();

// Calculați suma totală a facturilor emise
$total_amount_query = "SELECT SUM(total) FROM invoices";
$total_amount = $conn->query($total_amount_query)->fetchColumn();

// Calculați numărul de facturi achitate
$paid_invoices_query = "SELECT COUNT(*) FROM invoices WHERE status = 1";
$paid_invoices = $conn->query($paid_invoices_query)->fetchColumn();

// Calculați numărul de facturi neplătite
$unpaid_invoices_query = "SELECT COUNT(*) FROM invoices WHERE status = 0";
$unpaid_invoices = $conn->query($unpaid_invoices_query)->fetchColumn();

$pageTitle = "Vizualizare Facturi"; // Setează titlul paginii
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<style>
        .card-container {
            display: flex;
            gap: 20px; /* Spațiu între carduri */
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .card {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            min-height: 150px; /* Înălțime minimă constantă pentru toate cardurile */
        }

        .card-body {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }

        .card i {
            font-size: 40px;
            margin-left: 10px;
        }

        .card h2 {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .card p {
            font-size: 0.9rem;
            color: #666;
            margin: 0;
        }
        @media (max-width: 768px) {
        .card h2 {
            font-size: 1.2rem;
        }

        .card i {
            font-size: 30px;
            margin-left: 0;
        }
    }
    </style>
<body>

<?php include('inc/sidebar.php'); ?>
<?php include('inc/header.php'); ?>

<?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>

<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4">Vizualizare Facturi</h2>

        <!-- Carduri pentru statistici -->
        <div class="row mb-4">
    <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
        <div class="card shadow-sm border-0 rounded-lg">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="text-uppercase text-muted mb-2">Total Facturi</h6>
                        <h2 class="mb-0"><?php echo htmlspecialchars($total_invoices); ?></h2>
                    </div>
                    <div>
                        <i class="fas fa-file-invoice fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
        <div class="card shadow-sm border-0 rounded-lg">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="text-uppercase text-muted mb-2">Încasat / În așteptare</h6>
                        <h2 class="mb-0"><?php echo number_format($paid_amount, 2); ?> RON</h2>
                        <p class="text-muted mb-0">din <?php echo number_format($total_amount, 2); ?> RON</p>
                    </div>
                    <div>
                        <i class="fas fa-dollar-sign fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
        <div class="card shadow-sm border-0 rounded-lg">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="text-uppercase text-muted mb-2">Facturi Achitate</h6>
                        <h2 class="mb-0"><?php echo htmlspecialchars($paid_invoices); ?></h2>
                    </div>
                    <div>
                        <i class="fas fa-check-circle fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
        <div class="card shadow-sm border-0 rounded-lg">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="text-uppercase text-muted mb-2">Facturi Neplătite</h6>
                        <h2 class="mb-0"><?php echo htmlspecialchars($unpaid_invoices); ?></h2>
                    </div>
                    <div>
                        <i class="fas fa-times-circle fa-2x text-danger"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


        <!-- Formular de căutare -->
        <form action="" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Caută după nume client sau ID factură" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button class="btn btn-primary" type="submit">Caută</button>
            </div>
        </form>

        <!-- Tabel facturi -->
        <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID Factură</th>
                    <th>Client</th>
                    <th>Data</th>
                    <th>Total (RON)</th>
                    <th>Status</th>
                    <th>Acțiuni</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Construcția query-ului pentru căutare și paginare
                $limit = 10;
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $start = ($page - 1) * $limit;

                $searchQuery = '';
                if (isset($_GET['search']) && !empty($_GET['search'])) {
                    $search = htmlspecialchars($_GET['search']);
                    $searchQuery = "AND (clients.name LIKE '%$search%' OR invoices.id LIKE '%$search%')";
                }

                // Query pentru preluarea facturilor
                $query = "SELECT invoices.id, clients.name, invoices.date, invoices.total, invoices.status 
                          FROM invoices 
                          JOIN clients ON invoices.client_id = clients.id 
                          WHERE 1 $searchQuery 
                          ORDER BY invoices.id DESC 
                          LIMIT $start, $limit";

                $stmt = $conn->prepare($query);
                $stmt->execute();
                $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Afisarea facturilor in tabel
                if ($invoices) {
                    foreach ($invoices as $invoice) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($invoice['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($invoice['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($invoice['date']) . "</td>";
                        echo "<td>" . htmlspecialchars(number_format($invoice['total'], 2)) . "</td>";
                        echo "<td>";
                        if ($invoice['status'] == 1) {
                            echo '<span class="badge bg-success">Achitată</span>';
                        } else {
                            echo '<span class="badge bg-danger">Neplătită</span>';
                        }
                        echo "</td>";
                        echo '<td>';
                        echo '<a href="view_invoice.php?id=' . $invoice['id'] . '" class="btn btn-primary btn-sm">Vizualizeaza</a> ';
                        echo '<a href="invoicesys/export_invoice.php?id=' . $invoice['id'] . '" class="btn btn-success btn-sm">Exporta PDF</a> ';
                        echo '<button type="button" class="btn btn-danger btn-sm delete-invoice-btn" data-id="' . $invoice['id'] . '">Șterge</button>';
                        echo '</td>';
                        echo "</tr>";
                    }
                } else {
                    echo '<tr><td colspan="6" class="text-center">Nu s-au găsit facturi</td></tr>';
                }
                ?>
            </tbody>
        </table>
        </div>

        <!-- Paginare -->
        <?php
        $total_query = "SELECT COUNT(*) FROM invoices JOIN clients ON invoices.client_id = clients.id WHERE 1 $searchQuery";
        $stmt = $conn->prepare($total_query);
        $stmt->execute();
        $total_results = $stmt->fetchColumn();
        $total_pages = ceil($total_results / $limit);

        if ($total_pages > 1) {
            echo '<nav>';
            echo '<ul class="pagination justify-content-center">';
            for ($i = 1; $i <= $total_pages; $i++) {
                $active = $i == $page ? 'active' : '';
                echo '<li class="page-item ' . $active . '"><a class="page-link" href="?page=' . $i . '&search=' . (isset($search) ? $search : '') . '">' . $i . '</a></li>';
            }
            echo '</ul>';
            echo '</nav>';
        }
        ?>
    </div>
</div>

<?php include('inc/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-invoice-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const invoiceId = this.getAttribute('data-id');

            Swal.fire({
                title: 'Ești sigur că vrei să ștergi această factură?',
                text: 'Ștergerea acesteia este ireversibilă.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#555454',
                confirmButtonText: 'Da, șterge!',
                cancelButtonText: 'Anulează'
            }).then((result) => {
                if (result.isConfirmed) {
                    
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'invoicesys/delete_invoice.php'; // Asigură-te că calea este corectă

                    const inputId = document.createElement('input');
                    inputId.type = 'hidden';
                    inputId.name = 'id';
                    inputId.value = invoiceId;
                    form.appendChild(inputId);

                    document.body.appendChild(form);
                    form.submit(); // Trimite formularul
                }
            });
        });
    });
});
</script>


</body>
</html>
