<?php 
require 'db.php'; // Include conexiunea PDO la baza de date
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

// Obține lista de clienți existenți
$stmt = $conn->prepare("SELECT id, name, address, phone, email, company_name, company_cui, company_bank, company_iban, is_company FROM clients");
$stmt->execute();
$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Creare Factură"; // Setează titlul paginii
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
    <style>
        body {
            background-color: #f5f6fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .invoice-container {
            background-color: #ffffff;
            padding: 30px;
            margin: 20px auto;
            max-width: 1200px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            font-size: 1.2em;
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            padding: 20px;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .highlight-section {
            margin-bottom: 30px;
        }
        .highlight-title {
            color: #007bff;
            font-weight: bold;
            font-size: 1.2em;
        }
        .highlight-input {
            border: 2px solid #007bff;
            border-radius: 4px;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .form-row {
            margin-bottom: 15px;
        }
        .form-label {
            font-weight: bold;
        }
        .invoice-header {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .invoice-header > .card {
            flex: 1;
            margin-bottom: 20px;
        }
        .highlight {
            background-color: #d4edda;
            transition: background-color 0.5s ease;
        } 
        @media (max-width: 768px) {
            .invoice-header {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<?php include('inc/sidebar.php'); ?>
<?php include('inc/header.php'); ?>

<div class="main-content">
    <div class="invoice-container">
        <h2 class="mb-4 text-center">Creare Factură</h2>
        <form action="invoicesys/generate_invoice.php" method="POST">
        <div class="invoice-header">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-home"></i> Detalii Pensiune
                </div>
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="pension_name" class="form-label">Nume Pensiune</label>
                        <input type="text" class="form-control" id="pension_name" name="pension_name" value="Rasfatul RelaxSarii" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="pension_address" class="form-label">Adresa Pensiune</label>
                        <input type="text" class="form-control" id="pension_address" name="pension_address" value="Provita de jos, Jud. Prahova" required>
                    </div>
                </div>
            </div>

            <div class="card highlight-section">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-user"></i> Detalii Client
                </div>
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="existing_client" class="form-label highlight-title">Selectează Clientul</label>
                        <select class="form-control highlight-input" id="existing_client" name="existing_client" onchange="populateClientDetails()">
                            <option value="">Alege un client existent</option>
                            <?php foreach($clients as $client): ?>
                                <option value="<?php echo $client['id']; ?>"
                                        data-name="<?php echo $client['name']; ?>"
                                        data-address="<?php echo $client['address']; ?>"
                                        data-phone="<?php echo $client['phone']; ?>"
                                        data-email="<?php echo $client['email']; ?>"
                                        data-company_name="<?php echo $client['company_name']; ?>"
                                        data-company_cui="<?php echo $client['company_cui']; ?>"
                                        data-company_bank="<?php echo $client['company_bank']; ?>"
                                        data-company_iban="<?php echo $client['company_iban']; ?>"
                                        data-is_company="<?php echo $client['is_company']; ?>">
                                    <?php echo $client['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="client_name" class="form-label">Nume Client</label>
                        <input type="text" class="form-control" id="client_name" name="client_name" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="client_address" class="form-label">Adresa Client</label>
                        <input type="text" class="form-control" id="client_address" name="client_address" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="client_phone" class="form-label">Telefon Client</label>
                        <input type="text" class="form-control" id="client_phone" name="client_phone">
                    </div>
                    <div class="form-group mb-3">
                        <label for="client_email" class="form-label">Email Client</label>
                        <input type="email" class="form-control" id="client_email" name="client_email">
                    </div>
                    <div id="company_fields" style="display: none;">
                        <div class="form-group mb-3">
                            <label for="company_name" class="form-label">Denumire Firmă</label>
                            <input type="text" class="form-control" id="company_name" name="company_name">
                        </div>
                        <div class="form-group mb-3">
                            <label for="company_cui" class="form-label">Cod Unic de Înregistrare (CUI)</label>
                            <input type="text" class="form-control" id="company_cui" name="company_cui">
                        </div>
                        <div class="form-group mb-3">
                            <label for="company_bank" class="form-label">Bancă</label>
                            <input type="text" class="form-control" id="company_bank" name="company_bank">
                        </div>
                        <div class="form-group mb-3">
                            <label for="company_iban" class="form-label">IBAN</label>
                            <input type="text" class="form-control" id="company_iban" name="company_iban">
                        </div>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="is_company" name="is_company" onchange="toggleCompanyFields()">
                        <label class="form-check-label" for="is_company">Factura pe firmă</label>
                    </div>
                </div>
            </div>

        </div>

        <div class="card">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-list"></i> Servicii
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Descriere Serviciu</th>
                                <th>Cantitate</th>
                                <th>Preț/Unitate (RON)</th>
                                <th>Total (RON)</th>
                                <th>Acțiune</th>
                            </tr>
                        </thead>
                        <tbody id="services">
                            <tr>
                                <td><input type="text" class="form-control" name="service_description[]" required></td>
                                <td><input type="number" class="form-control" name="service_quantity[]" oninput="calculateTotal(this)" required></td>
                                <td><input type="number" step="0.01" class="form-control" name="service_unit_price[]" oninput="calculateTotal(this)" required></td>
                                <td class="service-total">0.00 RON</td>
                                <td><button type="button" class="btn btn-danger" onclick="removeService(this)">Șterge</button></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5" class="text-center">
                                    <button type="button" class="btn btn-outline-primary btn-sm" onclick="addService()"><i class="fas fa-plus"></i> Adaugă un alt serviciu</button>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                                <td colspan="2" id="total-invoice">0.00 RON</td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-end"><strong>TVA (19%):</strong></td>
                                <td colspan="2">
                                    <input type="checkbox" id="include-vat" name="include_vat" onchange="calculateInvoiceTotal()">
                                    <label for="include-vat">Aplică TVA</label>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Total Factură:</strong></td>
                                <td colspan="2" id="final-total">0.00 RON</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary btn-lg">Generează Factura</button>
        </div>
        </form>
    </div>
</div>

<?php include('inc/footer.php'); ?>

<script>

function toggleCompanyFields() {
    const isCompany = document.getElementById('is_company').checked;
    const companyFields = document.getElementById('company_fields');
    companyFields.style.display = isCompany ? 'block' : 'none';
}

function populateClientDetails() {
    const clientSelect = document.getElementById('existing_client');
    const selectedClient = clientSelect.options[clientSelect.selectedIndex];
    
    document.getElementById('client_name').value = selectedClient.getAttribute('data-name');
    document.getElementById('client_address').value = selectedClient.getAttribute('data-address');
    document.getElementById('client_phone').value = selectedClient.getAttribute('data-phone');
    document.getElementById('client_email').value = selectedClient.getAttribute('data-email');
    
    const isCompany = selectedClient.getAttribute('data-is_company') === "1";
    document.getElementById('is_company').checked = isCompany;
    
    const companyFields = document.getElementById('company_fields');
    companyFields.style.display = isCompany ? 'block' : 'none';
    
    if (isCompany) {
        document.getElementById('company_name').value = selectedClient.getAttribute('data-company_name');
        document.getElementById('company_cui').value = selectedClient.getAttribute('data-company_cui');
        document.getElementById('company_bank').value = selectedClient.getAttribute('data-company_bank');
        document.getElementById('company_iban').value = selectedClient.getAttribute('data-company_iban');
    } else {
        document.getElementById('company_name').value = '';
        document.getElementById('company_cui').value = '';
        document.getElementById('company_bank').value = '';
        document.getElementById('company_iban').value = '';
    }

    highlightSection('.highlight-section');
}

function highlightSection(selector) {
    const element = document.querySelector(selector);
    element.classList.add('highlight');
    setTimeout(() => {
        element.classList.remove('highlight');
    }, 2000);
}

function addService() {
    const serviceRow = `
        <tr>
            <td><input type="text" class="form-control" name="service_description[]" required></td>
            <td><input type="number" class="form-control" name="service_quantity[]" oninput="calculateTotal(this)" required></td>
            <td><input type="number" step="0.01" class="form-control" name="service_unit_price[]" oninput="calculateTotal(this)" required></td>
            <td class="service-total">0.00 RON</td>
            <td><button type="button" class="btn btn-danger" onclick="removeService(this)">Șterge</button></td>
        </tr>
    `;
    document.getElementById('services').insertAdjacentHTML('beforeend', serviceRow);
    highlightSection('#services');
}

function removeService(button) {
    button.closest('tr').remove();
    calculateInvoiceTotal();
    highlightSection('#services');
}

function calculateTotal(input) {
    const row = input.closest('tr');
    const quantity = parseFloat(row.querySelector('input[name="service_quantity[]"]').value) || 0;
    const unitPrice = parseFloat(row.querySelector('input[name="service_unit_price[]"]').value) || 0;
    const total = quantity * unitPrice;
    row.querySelector('.service-total').textContent = total.toFixed(2) + ' RON';
    calculateInvoiceTotal();
}

function calculateInvoiceTotal() {
    let subtotal = 0;
    document.querySelectorAll('.service-total').forEach(function(element) {
        subtotal += parseFloat(element.textContent);
    });

    let finalTotal = subtotal;
    const includeVAT = document.getElementById('include-vat').checked;
    if (includeVAT) {
        finalTotal += subtotal * 0.19;
    }

    document.getElementById('total-invoice').textContent = subtotal.toFixed(2) + ' RON';
    document.getElementById('final-total').textContent = finalTotal.toFixed(2) + ' RON';

    highlightSection('#final-total');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

