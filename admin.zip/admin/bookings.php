<?php
require 'db.php';
?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

<?php include('inc/sidebar.php') ?>
<?php include('inc/header.php') ?>


<div class="main-content">
    <h2>Rezervari</h2>
  <hr>
<?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: '" . $_SESSION['icon'] . "',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']);
                unset($_SESSION['icon']);  
            }
            ?>

    <div class="row">
        <div class="col-sm-2">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Adauga o rezervare</h5>
                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addBookingModal" style="width: 100%;"> <i class="fas fa-plus"></i> Adauga</a>
                </div>
            </div>
        </div>
        <div class="col-sm-2">
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Blocheaza o perioada</h5>
                <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#blockPeriodModal" style="width: 100%;"> <i class="fas fa-ban"></i> Blocheaza</a>
            </div>
        </div>
    </div>

    <!-- <div class="col-sm-2">
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Verifica calendar</h5>
                <a href="calendarphp.php" class="btn btn-sm btn-success"  style="width: 100%;"> <i class="fas fa-calendar"></i> Calendar</a>exampleModal
                <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal" style="width: 100%;"> <i class="fas fa-ban"></i> Blocheaza</a>

            </div>
        </div>
    </div> -->
    </div>

    <div class="row">
    <?php 
    $carduriPePagina = 8;

    $count_query = "SELECT COUNT(*) as id FROM bookings";
    $count_query_run = $conn->prepare($count_query);
    $count_query_run->execute();
    $count_result = $count_query_run->fetchColumn();
    
    $totalCarduri = $count_result;
    
    $totalPagini = ceil($totalCarduri / $carduriPePagina);
    
    if (!isset ($_GET['pagina']) ) {  
        $paginaCurenta  = 1;  
    } else {  
        $paginaCurenta = $_GET['pagina'];  
    }  
    $limita = ($paginaCurenta - 1) * $carduriPePagina;
    $offset = $carduriPePagina;
    

    $query = "SELECT * FROM bookings ORDER BY id DESC LIMIT :limita, :offset";
    $query_run = $conn->prepare($query);
    $query_run->bindParam(':limita', $limita, PDO::PARAM_INT);
    $query_run->bindParam(':offset', $offset, PDO::PARAM_INT);
    $query_run->execute();

    if($query_run->rowCount() > 0){
        while($row = $query_run->fetch()){
            $id = $row['id'];
            $bookingName = $row['nume_client'];
            $bookingNotes = $row['notes'];
            $bookingPayment = $row['payment'];
            $checkin = $row['checkin'];
            $checkout = $row['checkout'];
            $bookingStatus = $row['status'];

            $bookingCheckin = date('d/m/Y', strtotime($checkin));
            $bookingCheckout = date('d/m/Y', strtotime($checkout));
    
    ?>


    <div class='col-sm-3 mb-3'>
        <div class='card'>
            <div class='card-body'>
                <?php 
                if($bookingStatus == 0){
                    echo "<h5 class='card-title'>Rezervare noua!</h5>";
                }else if($bookingStatus >= 1){
                    echo "<h5 class='card-title'>Rezervare # $id </h5>";
                }
                ?>
                <p class='card-text'>
                    Perioada: <?php echo $bookingCheckin;?> - <?php echo $bookingCheckout;?>
                    <br> Nume: <?php echo $bookingName; ?>
                    <br>Status: 
                    <?php 
                    if($bookingStatus == 0){
                        echo "<span class='badge bg-warning'>In asteptare</span>";
                    }else if($bookingStatus == 1){
                        echo "<span class='badge bg-success'>Confirmat, in viitor</span>";
                    }else if($bookingStatus == 2){
                        echo "<span class='badge bg-success'>Finalizat</span>";
                    }else if($bookingStatus == 3){
                        echo "<span class='badge bg-danger'>Anulat</span>";
                    }
                    
                    ?>
                    <br>Plata: 
                    <?php 
                    if($bookingPayment == 0){
                        echo "<span class='badge bg-danger'>Neachitat</span>";
                    }else if($bookingPayment == 1){
                        echo "<span class='badge bg-warning'>Avans achitat</span>";
                    }else if($bookingPayment == 2){
                        echo "<span class='badge bg-success'>Plata completa</span>";
                    }
                    ?>
                </p>
                <a href='bookingdetails.php?id=<?php echo $id?>' class='btn btn-sm btn-primary' style='width: 100%;'>Vizualizeaza</a>
            </div>
        </div>
    </div>

    <?php
        }
    } else {
        echo "<div class='col-12'><div class='alert alert-secondary text-center'>Nu există rezervări active momentan.</div></div>";
    }
    ?>
</div>

         <?php
echo '<center>';
echo '<nav aria-label="Pagini">';
echo '<ul class="pagination justify-content-center">';
for ($p = 1; $p <= $totalPagini; $p++) {
    // Adaugă clasa "active" pentru pagina curentă
    if ($p == $paginaCurenta) {
        echo '<li class="page-item active" aria-current="page">';
    } else {
        echo '<li class="page-item">';
    }
    echo '<a class="page-link" href="bookings.php?pagina=' . $p . '">' . $p . '</a>';
    echo '</li>';
}
echo '</ul>';
echo '</nav>';
echo '</center>';
?>



<!-- Sectiune blocare perioade ocupate full -->

<h2>Perioade Blocate</h2>
<hr>
    <?php 
        generateBlockedPeriods($conn); 
    ?>
    </div>



<?php include('inc/footer.php') ?>

<?php
function generateBlockedPeriods($conn) {
    $blockedPeriodsQuery = "SELECT * FROM blocked_periods";
    $blockedPeriodsStmt = $conn->prepare($blockedPeriodsQuery);
    $blockedPeriodsStmt->execute();
    $blockedPeriods = $blockedPeriodsStmt->fetchAll(PDO::FETCH_ASSOC);

    echo '<div id="calendar" class="d-flex flex-wrap" style="gap: 15px;">';

    if (count($blockedPeriods) > 0) {
        foreach ($blockedPeriods as $period) {
            $startDate = new DateTime($period['start_date']);
            $endDate = new DateTime($period['end_date']);

            echo '<div class="card border-danger mb-3" style="max-width: 205px;">';
            echo '<div class="card-header bg-danger text-white p-2">';
            echo 'Perioadă blocată';
            echo '<form action="functions/blockedperiod_delete.php" method="POST" class="d-inline-block float-end">';
            echo '<input type="hidden" name="id" value="' . $period['id'] . '">';
            echo '<button type="submit" class="btn-close btn-close-white btn-sm" aria-label="Close"></button>';
            echo '</form>';
            echo '</div>';
            echo '<div class="card-body text-danger p-2">';
            echo '<h6 class="card-title mb-2">' . $startDate->format('d/m/Y') . ' - ' . $endDate->format('d/m/Y') . '</h6>';
            echo '<p class="card-text small">Perioada este blocată.</p>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<div class='col-12'><div class='alert alert-secondary text-center'>Nu există perioade blocate momentan.</div></div>";
    }

    echo '</div>';
}
?>


<!-- Modal pentru adaugarea unui noi rezervari -->
<div class="modal fade" id="addBookingModal" tabindex="-1" aria-labelledby="addBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addBookingModalLabel">Adauga o noua rezervare</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action= "functions/booking_create.php" method="POST">
            <div class="mb-3">
              <label for="bookingName" class="form-label">Nume client</label>
              <input type="text" class="form-control" id="bookingName" name = "bookingName" required>
            </div>
            <div class="mb-3">
              <label for="bookingClientPhone" class="form-label">Numar telefon client:</label>
              <input type="number" class="form-control" id="bookingClientPhone" name="bookingClientPhone" required>
            </div>
            <div class="mb-3">
              <label for="bookingClientMail" class="form-label">Email client:</label>
              <input type="mail" class="form-control" id="bookingClientMail" name="bookingClientMail" required>
            </div>
            <div class="mb-3">
              <label for="bookingNotes" class="form-label">Notatii rezervare</label>
              <textarea class="form-control" name="bookingNotes" id="bookingNotes" rows="2" required></textarea>
            </div>
            <div class="mb-3">
              <label for="bookingCheckin">Check in:</label>
              <input type="date" id="bookingCheckin" name="bookingCheckin" required>
             
              <label for="bookingCheckout">Check out:</label>
              <input type="date" id="bookingCheckout" name="bookingCheckout" required>
            </div>
            <div class="mb-3">
            <label for="bookingRoom" class="form-label">Selecteaza camera:</label>
            <select class="form-select" id="bookingRoom" name="bookingRoom" required>
                <option value="" selected>Alege o camera</option>
                <?php
                // Acesta este un cod PHP pentru a popula dropdown-ul cu camere disponibile din baza de date.
                $result = $conn->query("SELECT id, nume_camera FROM rooms");
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['nume_camera'] . "</option>";
                }
                ?>
            </select>
            </div>
            <div class="mb-3">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="yes" id="blockPeriod" name="blockPeriod">
              <label class="form-check-label" for="blockPeriod">
                Blocheaza rezervarile pe această perioadă!
              </label>
            </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" name = "submit_booking" >Adauga Rezervare</button>   
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<!-- Modal pentru blocarea perioadelor -->
<div class="modal fade" id="blockPeriodModal" tabindex="-1" aria-labelledby="blockPeriodModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="functions/blockedperiod_create.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="blockPeriodModalLabel">Blochează o perioadă</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="blockStartDate" class="form-label">Data de început</label>
                            <input type="date" class="form-control" id="blockStartDate" name="blockStartDate" required>
                        </div>
                        <div class="mb-3">
                            <label for="blockEndDate" class="form-label">Data de sfârșit</label>
                            <input type="date" class="form-control" id="blockEndDate" name="blockEndDate" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="submit_block" class="btn btn-warning">Blochează</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modalul -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Calendar</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <iframe src="calendarphp.php" style="width: 100%; height: 500px; border: none;"></iframe>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Închide</button>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
