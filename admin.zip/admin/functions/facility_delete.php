<?php
require '../db.php';
session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $query = "SELECT denumire_facilitate FROM facilitati WHERE id = :id";
    $query_run = $conn->prepare($query);
    $query_run->execute([':id' => $id]);
    $facility = $query_run->fetch(PDO::FETCH_ASSOC);
    
    $current_facilityName = $facility['denumire_facilitate'];

    $deleteQuery = "DELETE FROM facilitati WHERE id = :id";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($deleteStmt->execute()) {
        add_user_log($conn, $logged_in_user_id, "DELETE FACILITY: A sters facilitatea: ' $current_facilityName '");
        $_SESSION['message'] = "Ai sters o facilitate cu succes!";
        header('Location: ../rooms.php'); 
        exit();
    } else {
        echo "Eroare la ștergerea facilității.";
    }
} else {
    echo "ID-ul facilității nu a fost specificat.";
}
?>