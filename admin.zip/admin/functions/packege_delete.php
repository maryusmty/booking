<?php
require '../db.php';
session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Preia informațiile despre pachet, inclusiv imaginea
        $query = "SELECT denumire_pachet, imagine FROM packeges WHERE id = :id";
        $query_run = $conn->prepare($query);
        $query_run->execute([':id' => $id]);
        $packege = $query_run->fetch(PDO::FETCH_ASSOC);
        
        $current_packegeName = $packege['denumire_pachet'];
        $current_image = $packege['imagine'];

        // Adăugăm debug pentru a vedea calea imaginii corecte
        $image_path = '../packege_images/' . basename($current_image);
        echo "Calea imaginii este: " . $image_path . "<br>";

        // Verifică dacă imaginea este folosită de alte pachete
        if (!empty($current_image)) {
            $check_image_query = "SELECT COUNT(*) FROM packeges WHERE imagine = :imagine AND id != :id";
            $check_image_stmt = $conn->prepare($check_image_query);
            $check_image_stmt->execute([':imagine' => $current_image, ':id' => $id]);
            $image_count = $check_image_stmt->fetchColumn();

            // Dacă imaginea nu este folosită de alte pachete, o ștergem
            if ($image_count == 0 && file_exists($image_path)) {
                if (unlink($image_path)) {
                    echo "Imaginea a fost ștearsă cu succes.<br>";
                } else {
                    echo "Eroare la ștergerea imaginii.<br>";
                    error_log("Eroare la ștergerea imaginii: $image_path");
                }
            } else {
                if (!file_exists($image_path)) {
                    echo "Imaginea nu există la calea: $image_path<br>";
                    error_log("Imaginea nu există la calea: $image_path");
                }
            }
        }

        // Șterge înregistrarea pachetului din baza de date
        $stmt = $conn->prepare("DELETE FROM packeges WHERE id = :id");
        $stmt->execute([':id' => $id]);

        if ($stmt->rowCount() > 0) {
            add_user_log($conn, $logged_in_user_id, "DELETE PACKEGE: A sters pachetul cu numele: '$current_packegeName'");
            $_SESSION['message'] = "Ai sters pachetul cu succes!";
            $_SESSION['icon'] = "success";
            header('Location: ../packeges.php'); 
            exit;
        } else {
            echo "Eroare: Pachetul nu a putut fi șters.";
        }
    } else {
        echo "Parametrul ID lipsește.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
