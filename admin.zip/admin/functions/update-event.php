<?php

require '../db.php';

// Verifică dacă datele sunt trimise prin POST și sunt în format JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty(file_get_contents('php://input'))) {
    // Preia datele JSON trimise prin fetch
    $data = json_decode(file_get_contents('php://input'), true);

    // Extrage informațiile necesare
    $eventId = $data['id'];
    $newStart = $data['start'];
    $newEnd = $data['end'];

    // Asigură-te că datele sunt corect formatate și existente
    if ($eventId && $newStart && $newEnd) {
        // Scade o zi din data de checkout
        $adjustedEnd = date('Y-m-d', strtotime($newEnd . ' -1 day'));

        // Pregătește interogarea SQL pentru actualizare
        $sql = "UPDATE bookings SET checkin = :start, checkout = :end WHERE id = :id";
        $stmt = $conn->prepare($sql);

        // Execută actualizarea în baza de date
        if ($stmt->execute(['start' => $newStart, 'end' => $adjustedEnd, 'id' => $eventId])) {
            // Trimite un răspuns de succes
            echo json_encode(['status' => 'success']);
        } else {
            // Trimite un răspuns de eroare
            echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
        }
    } else {
        // Trimite un răspuns de eroare dacă datele sunt incomplete
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    }
} else {
    // Răspuns de eroare dacă metoda nu este POST sau dacă nu s-a primit JSON
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
