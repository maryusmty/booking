<?php
require '../db.php';
session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}
$logged_in_user_id = $_SESSION['user_id'];

//adaugare user
if (isset($_POST['submit_addUser'])) {
    $username = $_POST['addUsername'];
    $password = $_POST['addPassword'];
    $email = $_POST['addEmail'];
    $adminLevel = $_POST['addAdminLevel'];

    $username = htmlspecialchars(strip_tags($username));
    $password = htmlspecialchars(strip_tags($password));
    $email = htmlspecialchars(strip_tags($email));


    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO users (username, email, password, admin) VALUES (:username, :email, :password, :adminLevel)";
    $query_run = $conn->prepare($query);

    $data = [
        ':username' => $username,
        ':email' => $email,
        ':password' => $hashed_password,
        ':adminLevel' => $adminLevel,
    ];

    try {
        $query_execute = $query_run->execute($data);

        if ($query_execute) {
            $_SESSION['message'] = "Utilizatorul a fost adaugat cu succes!";
            echo "Succes";
            add_user_log($conn,$logged_in_user_id, "CREATE USER: A adaugat utilizatorul cu numele ' $username '");
            header('location:../users.php');
        } else {
            echo "Eroare: " . implode(", ", $query_run->errorInfo());
        }
    } catch (PDOException $e) {
        echo "Eroare PDO: " . $e->getMessage();
    }
}
    //editare user
    if (isset($_POST['submit_editUser'])) {
    $id = $_POST['id'];
    $new_username = $_POST['editUsername'];
    $new_password = $_POST['editPassword'];
    $new_email = $_POST['editEmail'];
    $new_adminLevel = $_POST['editAdminLevel'];

    
    $new_username = htmlspecialchars(strip_tags($new_username));
    $new_email = htmlspecialchars(strip_tags($new_email));

    
    $query = "SELECT * FROM users WHERE id = :id";
    $query_run = $conn->prepare($query);
    $query_run->execute([':id' => $id]);
    $current_user = $query_run->fetch();

    $current_username = $current_user['username'];
    $current_email = $current_user['email'];
    $current_adminLevel = $current_user['admin'];

   
    $log_message = "EDIT USER: A editat utilizatorul $current_username modificand: ";
    $changes_made = false;

    if ($new_username !== $current_username) {
        $log_message .= " numele din  ' $current_username '  în  ' $new_username '";
        $changes_made = true;
    }
    if ($new_email !== $current_email) {
        $log_message .= " emailul din  ' $current_email '  în  ' $new_email '";
        $changes_made = true;
    }
    if (!empty($new_password)) {
        $log_message .= " parola";
        $changes_made = true;
    }
    if ($new_adminLevel !== $current_adminLevel) {
        $log_message .= " ,gradul de administrare.";
        $changes_made = true;
    }

    if ($changes_made) {
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $query = "UPDATE users SET username = :username, email = :email, password = :password, admin = :adminLevel WHERE id = :id";
            $data = [
                ':username' => $new_username,
                ':email' => $new_email,
                ':password' => $hashed_password,
                ':adminLevel' => $new_adminLevel,
                ':id' => $id
            ];
        } else {
            $query = "UPDATE users SET username = :username, email = :email, admin = :adminLevel WHERE id = :id";
            $data = [
                ':username' => $new_username,
                ':email' => $new_email,
                ':adminLevel' => $new_adminLevel,
                ':id' => $id
            ];
        }

        $query_run = $conn->prepare($query);

        try {
            $query_execute = $query_run->execute($data);

            if ($query_execute) {
                add_user_log($conn, $logged_in_user_id, $log_message);

                echo "Succes";
                $_SESSION['message'] = "Profilul a fost actualizat cu succes!";
                header('location:../users.php');
            } else {
                echo "Eroare la actualizarea utilizatorului: " . implode(", ", $query_run->errorInfo());
            }
        } catch (PDOException $e) {
            echo "Eroare PDO: " . $e->getMessage();
        }
    } else {
        echo "Nu au fost efectuate modificări.";
    }
}


// stergere user
if (isset($_POST['submit_deleteUser'])) {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        $query = "SELECT username FROM users WHERE id = :id";
        $query_run = $conn->prepare($query);
        $query_run->execute([':id' => $id]);
        $current_username = $query_run->fetchColumn();

        $delete_log_message = "DELETE USER: A șters utilizatorul cu numele '$current_username'";

        $query = "DELETE FROM users WHERE id = :id";
        $query_run = $conn->prepare($query);

        $data = [
            ':id' => $id
        ];

        try {
            $query_execute = $query_run->execute($data);

            if ($query_execute) {
                echo "Succes";
                $_SESSION['message'] = "Profilul a fost șters cu succes!";
                add_user_log($conn, $logged_in_user_id, $delete_log_message);
                header('Location: ../users.php');
                exit;
            } else {
                echo "Eroare la executarea query-ului: " . implode(", ", $query_run->errorInfo());
            }
        } catch (PDOException $e) {
            echo "Eroare PDO: " . $e->getMessage();
        }
    } else {
        echo "Parametrul ID lipsește în formular.";
    }
}
?>
