<?php
require '../db.php';
session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        $query = "SELECT nume_camera FROM rooms WHERE id = :id";
        $query_run = $conn->prepare($query);
        $query_run->execute([':id' => $id]);
        $rooms = $query_run->fetch(PDO::FETCH_ASSOC);
        
        $current_roomName = $rooms['nume_camera'];
        
        $stmt = $conn->prepare("SELECT imagine FROM rooms WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $existing_images = $stmt->fetchColumn();

        
        if (!empty($existing_images)) {
            $existing_images = json_decode($existing_images, true);
            foreach ($existing_images as $image) {
                if (file_exists('../room_images/' . $image)) {
                    unlink('../room_images/' . $image);
                }
            }
        }

        // Șterge înregistrarea camerei din baza de date
        $stmt = $conn->prepare("DELETE FROM rooms WHERE id = :id");
        $stmt->execute([':id' => $id]);

        if ($stmt->rowCount() > 0) {
            add_user_log($conn, $logged_in_user_id, "DELETE ROOM: A sters camera cu numele: ' $current_roomName '");
            $_SESSION['message'] = "Ai sters camera cu succes!";
            $_SESSION['icon'] = "success";
            header('Location: ../rooms.php'); 
            exit;
        } else {
            echo "Eroare: Camera nu a putut fi ștearsă.";
        }
    } else {
        echo "Parametrul ID lipsește.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
