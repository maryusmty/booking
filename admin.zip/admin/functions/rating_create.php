<?php
require '../db.php';

if(isset($_POST['submit_rating'])){
    $rating_clientName = $_POST['rating_clientName'];
    $ratingText = $_POST['ratingText'];
    $ratingStatus = $_POST['ratingStatus'];
    $ratingStars = $_POST['ratingStars'];

    $denumire_pachet = htmlspecialchars(strip_tags($denumire_pachet));
    $descriere = htmlspecialchars(strip_tags($descriere));



    $query = "INSERT INTO ratings (nume_client, text_recenzie, stele_recenzie, status) VALUES (:nume_client, :text_recenzie, :stele_recenzie, :status)";
    $query_run = $conn->prepare($query);

    $data = [
        ':nume_client' => $rating_clientName,
        ':text_recenzie' => $ratingText,
        ':stele_recenzie' => $ratingStars,
        ':status' => $ratingStatus,
    ];

    $query_execute = $query_run->execute($data);

    if($query_execute){
        echo "Succes";
        header('location:../rating.php');
    }else{
        echo "Eroare: ". $e->getMessage();
    }
}
?>
