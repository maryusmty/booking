<?php
require '../db.php';

session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if(isset($_POST['submit_room'])){
    $denumire_camera = htmlspecialchars(strip_tags($_POST['roomName']));
    $status = htmlspecialchars(strip_tags($_POST['roomStatus']));
    $capacitate_camera = htmlspecialchars(strip_tags($_POST['roomCapacity']));
    $pret_saptamana = htmlspecialchars(strip_tags($_POST['roomPriceWeek']));
    $pret_weekend = htmlspecialchars(strip_tags($_POST['roomPriceWeekend']));

    if(isset($_FILES['roomImages']) && !empty($_FILES['roomImages']['name'][0])) {
        $images = $_FILES['roomImages'];

        $valid_extensions = array("jpg", "jpeg", "png");
        $uploaded_images = [];
        foreach($images['tmp_name'] as $key => $tmp_name) {
            $image_name = basename($images['name'][$key]);
            $image_extension = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));

            if(in_array($image_extension, $valid_extensions)) {
                $new_image_name = uniqid() . '.' . $image_extension;
                $upload_dir = '../room_images/';
                if(move_uploaded_file($tmp_name, $upload_dir . $new_image_name)) {
                    $uploaded_images[] = $new_image_name;
                }
            } else {
                echo "Tip de fișier invalid pentru: " . $image_name;
                exit();
            }
        }
        $images_json = json_encode($uploaded_images);

        $query = "INSERT INTO rooms (nume_camera, status, imagine, capacitate_camera, pret_saptamana, pret_weekend) 
                  VALUES (:denumire_camera, :status, :images, :capacitate, :pretNormal, :pretWeekend)";
        $query_run = $conn->prepare($query);

        $data = [
            ':denumire_camera' => $denumire_camera,
            ':status' => $status,
            ':images' => $images_json,
            ':capacitate' => $capacitate_camera,
            ':pretNormal' => $pret_saptamana,
            ':pretWeekend' => $pret_weekend
        ];

        try {
            $query_execute = $query_run->execute($data);

            if($query_execute){
                echo "Succes";
                add_user_log($conn, $logged_in_user_id, "CREATE ROOM: A adăugat camera cu numele: '$denumire_camera'");
                $_SESSION['message'] = "Ai adăugat o nouă cameră cu succes!";
                $_SESSION['icon'] = "success";
                header('location:../rooms.php');
                exit();
            } else {
                echo "Eroare la inserarea datelor";
            }
        } catch (PDOException $e) {
            echo "Eroare: ". $e->getMessage();
        }
    } else {
        echo "Nu a fost încărcată nicio imagine.";
    }
}
?>
