<?php
require '../db.php';
session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];


if(isset($_POST['submit_facility'])){
    $facilityName = $_POST['facilityName'];

    $facilityName = htmlspecialchars(strip_tags($facilityName));


    $query = "INSERT INTO facilitati (denumire_facilitate) VALUES (:facilityName)";
    $query_run = $conn->prepare($query);

    $data = [
        ':facilityName' => $facilityName,
    ];

    $query_execute = $query_run->execute($data);

    if($query_execute){
        echo "Succes";
        add_user_log($conn, $logged_in_user_id, "CREATE FACILITY: A adaugat o facilitate noua ' $facilityName '");
        $_SESSION['message'] = "Ai adaugat o facilitate cu succes!";
        header('location:../rooms.php');
    }else{
        echo "Eroare: ". $e->getMessage();
    }
}
?>
