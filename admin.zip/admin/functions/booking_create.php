<?php
require '../db.php';

session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if (isset($_POST['submit_booking'])) {
    $bookingName = $_POST['bookingName'];
    $bookingNotes = $_POST['bookingNotes'];
    $bookingPayment = 0;
    $bookingCheckin = $_POST['bookingCheckin'];
    $bookingCheckout = $_POST['bookingCheckout'];
    $bookingClientPhone = $_POST['bookingClientPhone'];
    $bookingClientMail = $_POST['bookingClientMail'];
    $room_id = $_POST['bookingRoom']; // Preluăm ID-ul camerei selectate
    $blockPeriod = isset($_POST['blockPeriod']) ? $_POST['blockPeriod'] : null;

    try {
        // Verificăm dacă perioada este blocată
        $query_period = "SELECT * FROM blocked_periods WHERE 
                         (:checkin < end_date AND :checkout > start_date)";
        $query_period_run = $conn->prepare($query_period);
        $query_period_run->bindParam(':checkin', $bookingCheckin);
        $query_period_run->bindParam(':checkout', $bookingCheckout);
        $query_period_run->execute();

        if ($query_period_run->rowCount() > 0) {
            $_SESSION['message'] = "Perioada este blocată și nu se poate înregistra o rezervare în timpul acesteia!";
            $_SESSION['icon'] = "error";
            header("Location: ../bookings.php?error=Perioada este blocată și nu se poate face rezervarea!");
            exit();
        } else {
            // Sanitizăm datele
            $bookingName = htmlspecialchars(strip_tags($bookingName));
            $bookingNotes = htmlspecialchars(strip_tags($bookingNotes));
            $bookingCheckin = htmlspecialchars(strip_tags($bookingCheckin));
            $bookingCheckout = htmlspecialchars(strip_tags($bookingCheckout));
            $bookingClientPhone = htmlspecialchars(strip_tags($bookingClientPhone));
            $bookingClientMail = htmlspecialchars(strip_tags($bookingClientMail));

            // Inserăm rezervarea în tabelul bookings
            $query = "INSERT INTO bookings (nume_client, notes, payment, checkin, checkout, phone, mail) 
                      VALUES (:bookingName, :bookingNotes, :bookingPayment, :bookingCheckin, :bookingCheckout, :bookingClientPhone, :bookingClientMail)";
            $query_run = $conn->prepare($query);

            $data = [
                ':bookingName' => $bookingName,
                ':bookingNotes' => $bookingNotes,
                ':bookingPayment' => $bookingPayment,
                ':bookingCheckin' => $bookingCheckin,
                ':bookingCheckout' => $bookingCheckout,
                ':bookingClientPhone' => $bookingClientPhone,
                ':bookingClientMail' => $bookingClientMail
            ];

            $query_execute = $query_run->execute($data);

            if ($query_execute) {
                $booking_id = $conn->lastInsertId(); // Obținem ID-ul rezervării inserate

                // Inserăm în tabelul booking_rooms
                $query_booking_rooms = "INSERT INTO booking_rooms (booking_id, room_id, checkin, checkout) 
                                        SELECT :booking_id, :room_id, checkin, checkout 
                                        FROM bookings 
                                        WHERE id = :booking_id";
                $query_booking_rooms_run = $conn->prepare($query_booking_rooms);
                $query_booking_rooms_run->bindParam(':booking_id', $booking_id);
                $query_booking_rooms_run->bindParam(':room_id', $room_id);
                $query_booking_rooms_run->execute();

                // Dacă checkbox-ul pentru blocare perioadă este selectat
                if ($blockPeriod == 'yes') {
                    $query_blockperiod = "INSERT INTO blocked_periods(start_date, end_date) VALUES (:checkin, :checkout)";
                    $run_query = $conn->prepare($query_blockperiod);
                    $run_query->bindParam(':checkin', $bookingCheckin);
                    $run_query->bindParam(':checkout', $bookingCheckout);
                    $run_query->execute();
                }

                // Adăugăm în jurnalul de utilizatori
                add_user_log($conn, $logged_in_user_id, "CREATE BOOKING: A adăugat o rezervare nouă pe numele '$bookingName' ");
                $_SESSION['message'] = "Rezervarea a fost înregistrată!";
                $_SESSION['icon'] = "success";
                header('Location: ../bookings.php');
                exit();
            } else {
                throw new Exception("Eroare la inserarea rezervării.");
            }
        }
    } catch (Exception $e) {
        echo "Eroare: " . $e->getMessage();
    }
}
?>
