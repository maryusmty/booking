<?php
// test.php

// Acest script nu face nimic altceva decât să returneze un mesaj simplu.
echo "Test.php a fost accesat cu succes!";

header('location:../debug_alerts.php');