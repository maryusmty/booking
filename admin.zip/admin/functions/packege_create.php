<?php
require '../db.php';

session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if (isset($_POST['submit_pachet'])) {
    $denumire_pachet = $_POST['denumire_pachet'];
    $descriere = $_POST['descriere_pachet'];
    $status = isset($_POST['status_check']) ? 1 : 0;
    $pret = $_POST['pret_pachet'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $camere_pachet = $_POST['camere_pachet']; // Camerele selectate

    // Sanitizarea input-urilor
    $denumire_pachet = htmlspecialchars(strip_tags($denumire_pachet));
    $descriere = htmlspecialchars(strip_tags($descriere));
    $pret = floatval($pret);
    $start_date = htmlspecialchars(strip_tags($start_date));
    $end_date = htmlspecialchars(strip_tags($end_date));

    // Gestionarea încărcării imaginii
    $target_dir = "../packege_images/";
    $imagine_pachet = basename($_FILES["imagine_pachet"]["name"]);
    $target_file = $target_dir . $imagine_pachet;
    $imageDB = "$imagine_pachet";  // Calea stocată în baza de date
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verificare dacă fișierul este o imagine reală
    $check = getimagesize($_FILES["imagine_pachet"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["imagine_pachet"]["tmp_name"], $target_file)) {
            // Fișier încărcat cu succes, se poate continua
        } else {
            $_SESSION['message'] = "Eroare la încărcarea imaginii.";
            $_SESSION['icon'] = "error";
            header("Location: ../packeges.php");
            exit(0);
        }
    } else {
        $_SESSION['message'] = "Fișierul selectat nu este o imagine.";
        $_SESSION['icon'] = "error";
        header("Location: ../packeges.php");
        exit(0);
    }

    // Adăugarea pachetului în baza de date, inclusiv calea imaginii și perioada de valabilitate
    $query = "INSERT INTO packeges (denumire_pachet, descriere, ultima_actualizare, status, pret, imagine, start_date, end_date) 
              VALUES (:denumire_pachet, :descriere, NOW(), :status, :pret, :imagine, :start_date, :end_date)";
    $query_run = $conn->prepare($query);

    $data = [
        ':denumire_pachet' => $denumire_pachet,
        ':descriere' => $descriere,
        ':status' => $status,
        ':pret' => $pret,
        ':imagine' => $imageDB,
        ':start_date' => $start_date,
        ':end_date' => $end_date
    ];

    try {
        $query_execute = $query_run->execute($data);

        if ($query_execute) {
            $package_id = $conn->lastInsertId(); // Obține ID-ul pachetului adăugat

            // Adăugarea camerelor selectate în tabelul `package_rooms`
            foreach ($camere_pachet as $camera_id) {
                $query_camera = "INSERT INTO package_rooms (package_id, room_id) VALUES (:package_id, :camera_id)";
                $stmt_camera = $conn->prepare($query_camera);
                $stmt_camera->bindParam(':package_id', $package_id);
                $stmt_camera->bindParam(':camera_id', $camera_id);
                $stmt_camera->execute();
            }

            add_user_log($conn, $logged_in_user_id, "CREATE PACKEGE: A adaugat pachetul cu numele: '$denumire_pachet'");
            $_SESSION['message'] = "Ai adaugat un pachet cu succes!";
            $_SESSION['icon'] = "success";
            header('location:../packeges.php');
            exit(0);
        } else {
            $_SESSION['message'] = "Eroare la adăugarea pachetului.";
            $_SESSION['icon'] = "error";
            header('location:../packeges.php');
            exit(0);
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "Eroare PDO: " . $e->getMessage();
        $_SESSION['icon'] = "error";
        header('location:../packeges.php');
        exit(0);
    }
}

