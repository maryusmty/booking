<?php
require '../db.php';

session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        if (isset($_POST['edit_booking'])) {
            $bookingName = $_POST['editBookingName'];
            $bookingNotes = $_POST['editBookingNotes'];
            $bookingStatus = $_POST['bookingStatus']; 
            $bookingPayment = $_POST['status_payment'];
            $bookingCheckin = $_POST['editBookingCheckin'];
            $bookingCheckout = $_POST['editBookingCheckout'];
            $bookingClientPhone = $_POST['editbookingClientPhone'];
            $bookingClientMail = $_POST['editbookingClientMail'];



            $bookingName = htmlspecialchars(strip_tags($bookingName));
            $bookingNotes = htmlspecialchars(strip_tags($bookingNotes));
            $bookingStatus = htmlspecialchars(strip_tags($bookingStatus));
            $bookingPayment = htmlspecialchars(strip_tags($bookingPayment));
            $bookingClientPhone = htmlspecialchars(strip_tags($bookingClientPhone));
            $bookingClientMail = htmlspecialchars(strip_tags($bookingClientMail));

            $query = "UPDATE bookings SET nume_client = :bookingName, notes = :bookingNotes, payment = :bookingPayment, status = :bookingStatus, phone = :bookingClientPhone, mail = :bookingClientMail, checkin = :bookingCheckin, checkout = :bookingCheckout WHERE id = :id";
            $query_run = $conn->prepare($query);

            $data = [
                ':bookingName' => $bookingName,
                ':bookingNotes' => $bookingNotes,
                ':bookingPayment' => $bookingPayment,
                ':bookingStatus' => $bookingStatus,
                ':bookingClientPhone' => $bookingClientPhone,
                ':bookingClientMail' => $bookingClientMail,
                ':bookingCheckin' => $bookingCheckin,
                ':bookingCheckout' => $bookingCheckout,
                ':id' => $id
            ];

            try {
                $query_execute = $query_run->execute($data);

                if ($query_execute) {
                    echo "Succes";
                    add_user_log($conn, $logged_in_user_id, "EDIT BOOKING: A modificat rezervarea de pe numele ' $bookingName '");
                    $_SESSION['message'] = "Rezervarea a fost editata!";
                    header('Location: ../bookingdetails.php?id='.$id);
                    exit;
                } else {
                    echo "Eroare la executarea query-ului: " . implode(", ", $query_run->errorInfo());
                }
            } catch (PDOException $e) {
                echo "Eroare PDO: " . $e->getMessage();
            }
        } else {
            echo "Formularul nu a fost trimis corect.";
        }
    } else {
        echo "Parametrul ID lipsește în formular.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
