<?php
require '../db.php';
session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];


if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $query = "SELECT start_date, end_date FROM blocked_periods WHERE id = :id";
    $query_run = $conn->prepare($query);
    $query_run->execute([':id' => $id]);
    $period = $query_run->fetch(PDO::FETCH_ASSOC);
    
    $current_start_date = $period['start_date'];
    $current_end_date = $period['end_date'];


    $delete_log_message = "UNBLOCK BOOKINGS: A deblocat rezervarile pe perioada: ' $current_start_date ' || ' $current_end_date ' ";

    $deleteQuery = "DELETE FROM blocked_periods WHERE id = :id";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($deleteStmt->execute()) {
        add_user_log($conn, $logged_in_user_id, $delete_log_message);
        $_SESSION['message'] = "Ai sters o perioada cu succes!";
        header('location: ../bookings.php');
    } else {
        echo "Eroare la ștergerea perioadei blocate.";
    }
} else {
    echo "ID-ul perioadei blocate nu a fost specificat.";
}
?>
