<?php
require '../db.php';

session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        $query = "SELECT nume_client FROM bookings WHERE id = :id";
        $query_run = $conn->prepare($query);
        $query_run->execute([':id' => $id]);
        $period = $query_run->fetch(PDO::FETCH_ASSOC);
        
        $current_bookingName = $period['nume_client'];

    
    
        $delete_log_message = "DELETE BOOKING: A sters rezervarea de pe numele ' $current_bookingName ' ";

        $query = "DELETE FROM bookings WHERE id = :id";
        $query_run = $conn->prepare($query);

        $data = [
            ':id' => $id
        ];

        try {
            $query_execute = $query_run->execute($data);

            if ($query_execute) {
                echo "Succes";
                add_user_log($conn, $logged_in_user_id, $delete_log_message);
                $_SESSION['message'] = "Rezervarea a fost stearsa!";
                $_SESSION['icon'] = "success";
                header('Location: ../bookings.php');
                exit;
            } else {
                echo "Eroare la executarea query-ului: " . implode(", ", $query_run->errorInfo());
            }
        } catch (PDOException $e) {
            echo "Eroare PDO: " . $e->getMessage();
        }
    } else {
        echo "Parametrul ID lipsește în formular.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
