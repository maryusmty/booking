<?php
require '../db.php';

session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $roomId = $_POST['room_id'];

    $query = "SELECT nume_camera FROM rooms WHERE id = :id";
    $query_run = $conn->prepare($query);
    $query_run->execute([':id' => $roomId]);
    $rooms = $query_run->fetch(PDO::FETCH_ASSOC);
    
    $current_roomName = $rooms['nume_camera'];
    
    if (isset($_POST['remove_facility'])) {
        $facilityId = $_POST['remove_facility'];
        $deleteQuery = "DELETE FROM room_facility WHERE room_id = :room_id AND facility_id = :facility_id";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bindParam(':room_id', $roomId);
        $deleteStmt->bindParam(':facility_id', $facilityId);
        $deleteStmt->execute();
    }

    if (isset($_POST['facility_ids'])) {
        foreach ($_POST['facility_ids'] as $facilityId) {
            $insertQuery = "INSERT INTO room_facility (room_id, facility_id) VALUES (:room_id, :facility_id)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bindParam(':room_id', $roomId);
            $insertStmt->bindParam(':facility_id', $facilityId);
            $insertStmt->execute();
        }
    }
    add_user_log($conn, $logged_in_user_id, "ROOM FACILITY: A editat facilitatile camerei cu numele: ' $current_roomName '");
    $_SESSION['message'] = "Facilitatile camerei au fost modificate cu succes!";
    header("Location: ../roomdetails.php?id=$roomId");
    exit();
}
?>