<?php
function generateBlockedPeriods($conn) {
    $blockedPeriodsQuery = "SELECT * FROM blocked_periods";
    $blockedPeriodsStmt = $conn->prepare($blockedPeriodsQuery);
    $blockedPeriodsStmt->execute();
    $blockedPeriods = $blockedPeriodsStmt->fetchAll(PDO::FETCH_ASSOC);

    echo '<div id="calendar" class="d-flex flex-wrap" style="gap: 15px;">';

    foreach ($blockedPeriods as $period) {
        $startDate = new DateTime($period['start_date']);
        $endDate = new DateTime($period['end_date']);

        echo '<div class="card border-danger mb-3" style="max-width: 205px;">';
        echo '<div class="card-header bg-danger text-white p-2">';
        echo 'Perioadă blocată';
        echo '<form action="functions/delete_blockedperiod.php" method="POST" class="d-inline-block float-end">';
        echo '<input type="hidden" name="id" value="' . $period['id'] . '">';
        echo '<button type="submit" class="btn-close btn-close-white btn-sm" aria-label="Close"></button>';
        echo '</form>';
        echo '</div>';
        echo '<div class="card-body text-danger p-2">';
        echo '<h6 class="card-title mb-2">' . $startDate->format('d/m/Y') . ' - ' . $endDate->format('d/m/Y') . '</h6>';
        echo '<p class="card-text small">Perioada este blocată.</p>';
        echo '</div>';
        echo '</div>';
    }

    echo '</div>';
}
?>