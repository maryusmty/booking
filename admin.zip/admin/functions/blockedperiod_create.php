<?php
require '../db.php';
session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];


if(isset($_POST['submit_block'])){
    $blockStartDate = $_POST['blockStartDate'];
    $blockEndDate = $_POST['blockEndDate'];

    $blockStartDate = htmlspecialchars(strip_tags($blockStartDate));
    $blockEndDate = htmlspecialchars(strip_tags($blockEndDate));

    $query = "INSERT INTO blocked_periods (start_date, end_date) VALUES (:blockStartDate, :blockEndDate)";
    $query_run = $conn->prepare($query);

    $data = [
        ':blockStartDate' => $blockStartDate,
        ':blockEndDate' => $blockEndDate
    ];

    $query_execute = $query_run->execute($data);

    if($query_execute){
        echo "Succes";
        add_user_log($conn, $logged_in_user_id, "BLOCK BOOKINGS: A blocat rezervarile pe perioada: ' $blockStartDate ' || ' $blockEndDate '");
        $_SESSION['message'] = "Ai blocat o perioada cu succes!";
        header('location: ../bookings.php');
    }else{
        echo "Eroare: ". $e->getMessage();
    }
}
?>
