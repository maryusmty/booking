<?php
session_start();
require '../db.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    $update_query = "UPDATE users SET status = 0 WHERE id = :user_id";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bindParam(':user_id', $user_id);
    $update_stmt->execute();
}

// Distruge sesiunea și redirecționează la pagina de login
session_destroy();
header("Location: ../login.php");
exit(0);
?>
