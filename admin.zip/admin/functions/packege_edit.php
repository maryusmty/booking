<?php
require '../db.php';
session_start();

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        if (isset($_POST['edit_pachet'])) {
            $denumire_pachet = $_POST['edit_denumire_pachet'];
            $descriere = $_POST['edit_descriere_pachet'];
            $status = isset($_POST['status_check']) ? 1 : 0;
            $pret = $_POST['edit_pret_pachet'];
            $start_date = $_POST['edit_start_date'];
            $end_date = $_POST['edit_end_date'];
            $selected_rooms = $_POST['edit_rooms'];

            // Sanitizarea input-urilor
            $denumire_pachet = htmlspecialchars(strip_tags($denumire_pachet));
            $descriere = htmlspecialchars(strip_tags($descriere));
            $status = htmlspecialchars(strip_tags($status));
            $pret = floatval($pret);
            $start_date = htmlspecialchars(strip_tags($start_date));
            $end_date = htmlspecialchars(strip_tags($end_date));

            // Verifică dacă a fost încărcată o nouă imagine
            $imagine_noua = !empty($_FILES['edit_imagine_pachet']['name']);
            $imagine_pachet = "";

            if ($imagine_noua) {
                $target_dir = "../packege_images/";
                $imagine_pachet = basename($_FILES['edit_imagine_pachet']['name']);
                $target_file = $target_dir . $imagine_pachet;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                // Verifică dacă fișierul este o imagine reală
                $check = getimagesize($_FILES['edit_imagine_pachet']['tmp_name']);
                if ($check === false) {
                    $_SESSION['message'] = "Fișierul selectat nu este o imagine.";
                    header("Location: ../packegedetails.php?id=$id");
                    exit(0);
                }

                // Verifică dacă imaginea poate fi încărcată
                if (!move_uploaded_file($_FILES['edit_imagine_pachet']['tmp_name'], $target_file)) {
                    $_SESSION['message'] = "Eroare la încărcarea imaginii.";
                    header("Location: ../packegedetails.php?id=$id");
                    exit(0);
                }

                // Șterge imaginea veche din director dacă nu este folosită de alte pachete
                $query_old_image = "SELECT imagine FROM packeges WHERE id = :id";
                $stmt_old_image = $conn->prepare($query_old_image);
                $stmt_old_image->execute([':id' => $id]);
                $old_image = $stmt_old_image->fetchColumn();

                if ($old_image && $old_image !== $imagine_pachet) {
                    $check_image_query = "SELECT COUNT(*) FROM packeges WHERE imagine = :imagine AND id != :id";
                    $check_image_stmt = $conn->prepare($check_image_query);
                    $check_image_stmt->execute([':imagine' => $old_image, ':id' => $id]);
                    $image_count = $check_image_stmt->fetchColumn();

                    if ($image_count == 0 && file_exists("../packege_images/" . $old_image)) {
                        unlink("../packege_images/" . $old_image); // Șterge imaginea veche
                    }
                }
            }

            // Construirea query-ului de actualizare
            if ($imagine_noua) {
                $query = "UPDATE packeges SET denumire_pachet = :denumire_pachet, descriere = :descriere, ultima_actualizare = NOW(), status = :status, pret = :pret, imagine = :imagine, start_date = :start_date, end_date = :end_date WHERE id = :id";
                $data = [
                    ':denumire_pachet' => $denumire_pachet,
                    ':descriere' => $descriere,
                    ':status' => $status,
                    ':pret' => $pret,
                    ':imagine' => $imagine_pachet,
                    ':start_date' => $start_date,
                    ':end_date' => $end_date,
                    ':id' => $id
                ];
            } else {
                $query = "UPDATE packeges SET denumire_pachet = :denumire_pachet, descriere = :descriere, ultima_actualizare = NOW(), status = :status, pret = :pret, start_date = :start_date, end_date = :end_date WHERE id = :id";
                $data = [
                    ':denumire_pachet' => $denumire_pachet,
                    ':descriere' => $descriere,
                    ':status' => $status,
                    ':pret' => $pret,
                    ':start_date' => $start_date,
                    ':end_date' => $end_date,
                    ':id' => $id
                ];
            }

            // Executarea query-ului
            $query_run = $conn->prepare($query);

            try {
                $query_execute = $query_run->execute($data);

                if ($query_execute) {
                    // Actualizarea camerelor asociate pachetului
                    $delete_rooms_query = "DELETE FROM package_rooms WHERE package_id = :packege_id";
                    $delete_stmt = $conn->prepare($delete_rooms_query);
                    $delete_stmt->execute([':packege_id' => $id]);

                    $insert_room_query = "INSERT INTO package_rooms (package_id, room_id) VALUES (:packege_id, :room_id)";
                    $insert_room_stmt = $conn->prepare($insert_room_query);

                    foreach ($selected_rooms as $room_id) {
                        $insert_room_stmt->execute([':packege_id' => $id, ':room_id' => $room_id]);
                    }

                    add_user_log($conn, $logged_in_user_id, "EDIT PACKEGE: A editat pachetul cu numele: '$denumire_pachet'");
                    $_SESSION['message'] = "Ai editat un pachet cu succes!";
                    header('Location: ../packegedetails.php?id=' . $id);
                    exit;
                } else {
                    echo "Eroare la executarea query-ului: " . implode(", ", $query_run->errorInfo());
                }
            } catch (PDOException $e) {
                echo "Eroare PDO: " . $e->getMessage();
            }
        } else {
            echo "Formularul nu a fost trimis corect.";
        }
    } else {
        echo "Parametrul ID lipsește în formular.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
