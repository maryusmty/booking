<?php
require '../db.php';

session_start();
function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}

$logged_in_user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        if (isset($_POST['edit_room'])) {
            $denumire_camera = $_POST['editRoomName'];
            $status = $_POST['editRoomStatus'];
            $capacitate_camera = $_POST['editRoomCapacity'];
            $pret_saptamana = $_POST['editRoomPriceWeek'];
            $pret_weekend = $_POST['editRoomPriceWeekend'];

            // Sanitize inputs
            $denumire_camera = htmlspecialchars(strip_tags($denumire_camera));
            $status = htmlspecialchars(strip_tags($status));
            $capacitate_camera = htmlspecialchars(strip_tags($capacitate_camera));
            $pret_saptamana = htmlspecialchars(strip_tags($pret_saptamana));
            $pret_weekend = htmlspecialchars(strip_tags($pret_weekend));

            // Gestionarea imaginilor
            $uploaded_images = [];
            $remove_images = isset($_POST['remove_images']) ? $_POST['remove_images'] : [];

            // Obține imaginile existente din baza de date
            $stmt = $conn->prepare("SELECT imagine FROM rooms WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $existing_images = $stmt->fetchColumn();

            $existing_images = !empty($existing_images) ? json_decode($existing_images, true) : [];

            // Șterge imaginile selectate atât din lista de imagini cât și din sistem
            foreach ($remove_images as $image) {
                if (in_array($image, $existing_images)) {
                    // Elimină imaginea din array
                    $existing_images = array_diff($existing_images, [$image]);

                    // Șterge fișierul din sistem
                    if (file_exists('../room_images/' . $image)) {
                        unlink('../room_images/' . $image);
                    }
                }
            }

            // Upload noi imagini
            if (isset($_FILES['roomImages']) && !empty($_FILES['roomImages']['name'][0])) {
                $images = $_FILES['roomImages'];
                $valid_extensions = ["jpg", "jpeg", "png"];

                foreach ($images['tmp_name'] as $key => $tmp_name) {
                    $file_extension = pathinfo($images['name'][$key], PATHINFO_EXTENSION);
                    if (in_array($file_extension, $valid_extensions)) {
                        $new_file_name = uniqid() . '.' . $file_extension;
                        $upload_path = '../room_images/' . $new_file_name;

                        if (move_uploaded_file($tmp_name, $upload_path)) {
                            $uploaded_images[] = $new_file_name;
                        }
                    }
                }
            }

            // Combina imaginile existente (după ștergeri) cu cele noi
            $final_images = array_merge($existing_images, $uploaded_images);

            // Transformă array-ul într-un string JSON pentru stocare în baza de date
            $final_images_string = json_encode($final_images);

            // Actualizează baza de date
            $query = "UPDATE rooms 
                      SET nume_camera = :denumire_camera, 
                          status = :status, 
                          imagine = :images, 
                          capacitate_camera = :capacitate_camera, 
                          pret_saptamana = :pret_saptamana, 
                          pret_weekend = :pret_weekend 
                      WHERE id = :id";
            $query_run = $conn->prepare($query);

            $data = [
                ':denumire_camera' => $denumire_camera,
                ':status' => $status,
                ':images' => $final_images_string,
                ':capacitate_camera' => $capacitate_camera,
                ':pret_saptamana' => $pret_saptamana,
                ':pret_weekend' => $pret_weekend,
                ':id' => $id
            ];

            try {
                $query_execute = $query_run->execute($data);

                if ($query_execute) {
                    add_user_log($conn, $logged_in_user_id, "EDIT ROOM: A editat camera cu numele: ' $denumire_camera '");
                    $_SESSION['message'] = "Ai editat camera cu succes!";
                    header('Location: ../roomdetails.php?id='.$id);
                    exit;
                } else {
                    echo "Eroare la executarea query-ului: " . implode(", ", $query_run->errorInfo());
                }
            } catch (PDOException $e) {
                echo "Eroare PDO: " . $e->getMessage();
            }
        } else {
            echo "Formularul nu a fost trimis corect.";
        }
    } else {
        echo "Parametrul ID lipsește în formular.";
    }
} else {
    echo "Request method nu este POST.";
}
?>
