<?php require 'db.php'; ?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    // Obținerea detaliilor camerei
    $query = "SELECT * FROM rooms WHERE id = ?";
    $query_run = $conn->prepare($query);
    $query_run->execute([$id]);

    if($query_run->rowCount() > 0){
        $row = $query_run->fetch();

        $roomName = $row['nume_camera'];
        $roomStatus = $row['status'];
        $roomCapacity = $row['capacitate_camera'];
        $roomNormalPrice = $row['pret_saptamana'];
        $roomWeekendPrice = $row['pret_weekend'];
        
        // Obținerea imaginilor asociate camerei
        $image_query = "SELECT * FROM rooms WHERE id = ?";
        $image_stmt = $conn->prepare($image_query);
        $image_stmt->execute([$id]);
        $roomImages = json_decode($row['imagine'], true);

    } else {
        echo "Camera nu a fost găsită.";
    }
}
// Determină ziua curentă
$today = date('N'); // 'N' returnează ziua săptămânii în format numeric (1 pentru Luni, 7 pentru Duminică)
// $today = 3;
// Alege prețul în funcție de ziua săptămânii
if ($today >= 6) { // Dacă este Sâmbătă (6) sau Duminică (7)
    $displayPrice = $roomWeekendPrice;
} else { // În timpul săptămânii (Luni până Vineri)
    $displayPrice = $roomNormalPrice;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalii Camera - <?php echo $roomName; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
    <style>
        .room-detail-section {
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .room-detail-title {
            margin-bottom: 15px;
        }
        .room-images img {
            max-height: 200px;
            object-fit: cover;
            border-radius: 5px;
        }
        .facility-badge {
            margin: 5px 5px 5px 0;
        }
    </style>
</head>
<body>

<?php include("inc/sidebar.php") ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <!-- Secțiune de detalii ale camerei -->
                <div class="room-detail-section">
                    <h2 class="room-detail-title"><i class="fas fa-info-circle"></i> Detalii <?php echo $roomName; ?></h2>
                    <p><strong>Status:</strong> 
                        <?php
                            if($roomStatus == 0){
                                echo "<span class='badge bg-danger'>Nelistată</span>";
                            } else if($roomStatus == 1){
                                echo "<span class='badge bg-success'>Listată</span>";
                            } else if($roomStatus == 2){
                                echo "<span class='badge bg-warning text-dark'>Mentenanță</span>";
                            }
                        ?>
                    </p>
                    <p><strong>Capacitate:</strong> <?php echo htmlspecialchars($roomCapacity); ?> persoane</p>
                    <p><strong>Preț pe noapte:</strong> <?php echo htmlspecialchars($roomNormalPrice); ?> RON (Timpul săptămânii), <?php echo htmlspecialchars($roomWeekendPrice); ?> RON (Weekend)</p>
                    <p><strong>Preț afișat pentru clienti:</strong> <?php echo htmlspecialchars($displayPrice); ?> RON</p>
                </div>

<!-- Secțiune de imagini -->
<div class="room-detail-section">
    <h3 class="room-detail-title"><i class="fas fa-images"></i> Imagini</h3>
    <?php if (!empty($roomImages)): ?>
        <div id="carouselRoomImages" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php foreach ($roomImages as $index => $image): ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <img src="room_images/<?php echo htmlspecialchars($image); ?>" class="d-block w-100 room-images" alt="Imagine camera" style="height: 200px; object-fit: contain;">
                    </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselRoomImages" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselRoomImages" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    <?php else: ?>
        <p>Nu există imagini pentru această cameră.</p>
    <?php endif; ?>
</div>

                <!-- Secțiune de facilități -->
                <div class="room-detail-section">
                    <h3 class="room-detail-title"><i class="fas fa-concierge-bell"></i> Facilitățile camerei</h3>
                    <div class="row">
                    <?php
                        // Selectarea facilităților active pentru această cameră
                        $activeFacilitiesQuery = "SELECT f.id, f.denumire_facilitate FROM facilitati f
                                                INNER JOIN room_facility rf ON f.id = rf.facility_id
                                                WHERE rf.room_id = :room_id";
                        $activeStmt = $conn->prepare($activeFacilitiesQuery);
                        $activeStmt->bindParam(':room_id', $id);
                        $activeStmt->execute();
                        $activeFacilities = $activeStmt->fetchAll(PDO::FETCH_ASSOC);

                        if ($activeFacilities) {
                            foreach ($activeFacilities as $facility) {
                                echo '<div class="col-auto"><span class="badge bg-secondary facility-badge">' . htmlspecialchars($facility['denumire_facilitate']) . '</span></div>';
                            }
                        } else {
                            echo "<p>Nu există facilități active pentru această cameră.</p>";
                        }
                    ?>
                    </div>
                </div>
            </div>
                        

            <div class="col-md-4">
                <!-- Secțiune de acțiuni -->
                <div class="room-detail-section">
                    <h4 class="room-detail-title"><i class="fas fa-cogs"></i> Acțiuni</h4>
                    <button class="btn btn-warning w-100 mb-2" data-bs-toggle="modal" data-bs-target="#addFacilityModal?<?php echo $id;?>"><i class="fas fa-edit"></i> Modifică facilități</button>
                    <button class="btn btn-primary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#editRoomModal?<?php echo $id;?>"><i class="fas fa-edit"></i> Editare cameră</button>
                    <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#deleteBookingModal?<?php echo $id;?>"><i class="fas fa-trash-alt"></i> Ștergere cameră</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("inc/footer.php") ?>

<!-- Modal pentru editarea unei camere -->
<div class="modal fade" id="editRoomModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="editRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editRoomModalLabel">Editează camera</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Închide"></button>
            </div>
            <div class="modal-body">
                <form action="functions/room_edit.php" method="POST" enctype="multipart/form-data">
                    <!-- Input ascuns pentru ID-ul camerei -->
                    <input type="hidden" id="roomId" name="id" value="<?php echo $id; ?>">

                    <!-- Titlu cameră -->
                    <div class="mb-3">
                        <label for="editRoomName" class="form-label">Titlu cameră</label>
                        <input type="text" class="form-control" id="editRoomName" name="editRoomName" value="<?php echo htmlspecialchars($roomName); ?>" required>
                    </div>

                    <!-- Capacitate cameră -->
                    <div class="mb-3">
                        <label for="editRoomCapacity" class="form-label">Capacitate cameră</label>
                        <input type="number" class="form-control" id="editRoomCapacity" name="editRoomCapacity" value="<?php echo htmlspecialchars($roomCapacity); ?>" required>
                    </div>

                    <!-- Preț cameră (în timpul săptămânii) -->
                    <div class="mb-3">
                        <label for="editRoomPriceWeek" class="form-label">Preț pe noapte (timpul săptămânii)</label>
                        <input type="number" class="form-control" id="editRoomPriceWeek" name="editRoomPriceWeek" value="<?php echo htmlspecialchars($roomNormalPrice); ?>" required>
                    </div>

                    <!-- Preț cameră (în weekend) -->
                    <div class="mb-3">
                        <label for="editRoomPriceWeekend" class="form-label">Preț pe noapte (weekend)</label>
                        <input type="number" class="form-control" id="editRoomPriceWeekend" name="editRoomPriceWeekend" value="<?php echo htmlspecialchars($roomWeekendPrice); ?>" required>
                    </div>

                    <!-- Imagini cameră -->
                    <div class="mb-3">
                        <label for="editRoomImages" class="form-label">Adauga imagini</label>
                        <input type="file" class="form-control" id="editRoomImages" name="roomImages[]" multiple>

                        <!-- Afișare imagini existente -->
                        <div class="mt-2">
                            <p>Imagini actuale:</p>
                            <?php
                            if (!empty($roomImages)) {
                                foreach ($roomImages as $image) {
                                    echo '<div class="existing-image mb-2">';
                                    echo '<img src="room_images/' . htmlspecialchars($image) . '" alt="Room Image" class="img-thumbnail" width="100">';
                                    echo '<input type="checkbox" name="remove_images[]" value="' . htmlspecialchars($image) . '"> Șterge această imagine';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p>Nu există imagini pentru această cameră.</p>';
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Status cameră -->
                    <div class="mb-3">
                        <label for="editRoomStatus" class="form-label">Status cameră:</label>
                        <div>
                            <input type="radio" id="editRoomStatus_0" name="editRoomStatus" value="0" <?php echo $roomStatus == 0 ? 'checked' : ''; ?>>
                            <label for="editRoomStatus_0">Nelistată</label>

                            <input type="radio" id="editRoomStatus_1" name="editRoomStatus" value="1" <?php echo $roomStatus == 1 ? 'checked' : ''; ?>>
                            <label for="editRoomStatus_1">Listată</label>

                            <input type="radio" id="editRoomStatus_2" name="editRoomStatus" value="2" <?php echo $roomStatus == 2 ? 'checked' : ''; ?>>
                            <label for="editRoomStatus_2">Mentenanță</label>
                        </div>
                    </div>

                    <!-- Buton de salvare -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="edit_room">Salvează modificările</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pentru ștergerea unei camere -->
<div class="modal fade" id="deleteBookingModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="deleteBookingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteBookingModalLabel">Șterge camera</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/room_delete.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <div class="mb-3">
                        <h6>Sunteți sigur că doriți să ștergeți <b><?php echo $roomName; ?></b>?</h6>
                    </div>
                    <button type="submit" class="btn btn-danger" name="sterge_booking">Da, șterge</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pentru gestionarea facilităților -->
<div class="modal fade" id="addFacilityModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="addFacilityModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Gestionare Facilități pentru <?php echo htmlspecialchars($roomName); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/room_facility.php" method="POST">
                    <input type="hidden" name="room_id" value="<?php echo $id; ?>">

                    <!-- Facilități active -->
                    <div class="mb-4">
                        <h6 class="mb-3">Facilități active</h6>
                        <div class="row g-2">
                            <?php
                            if (isset($activeFacilities) && !empty($activeFacilities)) {
                                foreach ($activeFacilities as $facility) {
                                    ?>
                                    <div class="col-auto">
                                        <small class="d-inline-flex align-items-center px-3 py-2 fw-semibold text-dark bg-light border border-dark rounded-pill">
                                            <?php echo htmlspecialchars($facility['denumire_facilitate']); ?>
                                            <button type="submit" class="btn-close btn-sm" aria-label="Remove" name="remove_facility" value="<?php echo $facility['id']; ?>"></button>
                                        </small>
                                    </div>
                                    <?php
                                }
                            } else {
                                echo "<p>Nu există facilități active pentru această cameră.</p>";
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Facilități disponibile -->
                    <div class="mb-4">
                        <h6 class="mb-3">Alte facilități disponibile</h6>
                        <div class="row g-2">
                            <?php
                            // Selectarea facilităților disponibile care nu sunt deja active
                            $availableFacilitiesQuery = "SELECT * FROM facilitati f
                                                        WHERE f.id NOT IN (SELECT facility_id FROM room_facility WHERE room_id = :room_id)";
                            $availableStmt = $conn->prepare($availableFacilitiesQuery);
                            $availableStmt->bindParam(':room_id', $id);
                            $availableStmt->execute();
                            $availableFacilities = $availableStmt->fetchAll(PDO::FETCH_ASSOC);

                            if ($availableFacilities) {
                                foreach ($availableFacilities as $facility) {
                                    ?>
                                    <div class="col-auto">
                                        <small class="d-inline-flex align-items-center px-3 py-2 fw-semibold text-dark bg-light border border-dark rounded-pill">
                                            <?php echo htmlspecialchars($facility['denumire_facilitate']); ?>
                                            <input type="checkbox" name="facility_ids[]" value="<?php echo $facility['id']; ?>" class="form-check-input ms-2">
                                        </small>
                                    </div>
                                    <?php
                                }
                            } else {
                                echo "<p class='text-center'>Nu există alte facilități disponibile în acest moment.</p>";
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Buton pentru salvare -->
                    <div class="text-end">
                        <button type="submit" class="btn btn-warning text-dark">Salvează modificările</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
