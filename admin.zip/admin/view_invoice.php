<?php
session_start();
require 'db.php';
require 'invoicesys/invoice_functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

if (!isset($_GET['id'])) {
    header("Location: manage_invoices.php");
    exit(0);
}

$invoice_id = $_GET['id'];

// Verifică dacă formularul de actualizare a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['status'])) {
    $status = $_POST['status'];
    
    // Actualizare status în baza de date
    $stmt = $conn->prepare("UPDATE invoices SET status = :status WHERE id = :invoice_id");
    $stmt->execute([
        ':status' => $status,
        ':invoice_id' => $invoice_id
    ]);

    $_SESSION['message'] = "Ai modificat statusul platii al facturii # $invoice_id cu succes!";
    header("Location: view_invoice.php?id=$invoice_id");
    exit(0);
}

// Preluare detalii factură
$invoice = get_invoice_details($conn, $invoice_id);
$invoice_items = get_invoice_items($conn, $invoice_id);

if (!$invoice) {
    header("Location: manage_invoices.php");
    exit(0);
}

$pageTitle = "Vizualizare Factură #$invoice_id"; // Setează titlul paginii
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

<?php include('inc/sidebar.php'); ?>
<?php include('inc/header.php'); ?>

<?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>


<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4">Vizualizare Factură #<?php echo htmlspecialchars($invoice_id); ?></h2>

        <div class="row mb-4">
            <div class="col-md-6">
                <h4>Detalii Client</h4>
                <p><strong>Nume:</strong> <?php echo htmlspecialchars($invoice['name']); ?></p>
                <p><strong>Adresă:</strong> <?php echo htmlspecialchars($invoice['address']); ?></p>
                <p><strong>Telefon:</strong> <?php echo htmlspecialchars($invoice['phone']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($invoice['email']); ?></p>
            </div>
            <div class="col-md-6">
                <h4>Detalii Factură</h4>
                <p><strong>Data:</strong> <?php echo htmlspecialchars($invoice['date']); ?></p>
                <p><strong>Total:</strong> <?php echo htmlspecialchars(number_format($invoice['total'], 2)); ?> RON</p>
                <p><strong>Status:</strong> 
                    <form action="view_invoice.php?id=<?php echo htmlspecialchars($invoice_id); ?>" method="POST" style="display: inline;">
                        <select name="status" onchange="this.form.submit()" class="form-select d-inline w-auto">
                            <option value="1" <?php echo $invoice['status'] == 1 ? 'selected' : ''; ?>>Achitată</option>
                            <option value="0" <?php echo $invoice['status'] == 0 ? 'selected' : ''; ?>>Neplătită</option>
                        </select>
                    </form>
                </p>
            </div>
        </div>

        <h4>Articole Factură</h4>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Descriere</th>
                    <th>Cantitate</th>
                    <th>Preț Unitar (RON)</th>
                    <th>Total (RON)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoice_items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['description']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td><?php echo htmlspecialchars(number_format($item['unit_price'], 2)); ?></td>
                    <td><?php echo htmlspecialchars(number_format($item['total_price'], 2)); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="invoicesys/export_invoice.php?id=<?php echo htmlspecialchars($invoice_id); ?>" class="btn btn-success">Exportă PDF</a>
        <a href="manage_invoices.php" class="btn btn-secondary">Înapoi la facturi</a>
    </div>
</div>

<?php include('inc/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
