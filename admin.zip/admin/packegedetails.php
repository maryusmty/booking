<?php require 'db.php'; ?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    // Obținerea detaliilor pachetului
    $query = "SELECT * FROM packeges WHERE id = ?";
    $query_run = $conn->prepare($query);
    $query_run->execute([$id]);

    if($query_run->rowCount() > 0){
        $row = $query_run->fetch();

        $denumire_pachet = $row['denumire_pachet'];
        $descriere = $row['descriere'];
        $ultima_actualizare = $row['ultima_actualizare'];
        $status = $row['status'];
        $pret = $row['pret'];
        $start_date = $row['start_date'];
        $end_date = $row['end_date'];
        $imagine = $row['imagine'];

        // Obținerea camerelor asociate pachetului
        $rooms_query = "SELECT r.* FROM rooms r 
                        INNER JOIN package_rooms pr ON r.id = pr.room_id 
                        WHERE pr.package_id = ?";
        $rooms_stmt = $conn->prepare($rooms_query);
        $rooms_stmt->execute([$id]);
        $rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

    } else {
        echo "Pachetul nu a fost găsit.";
    }
} 

$capacitate_totala = 0;
foreach ($rooms as $room) {
    $capacitate_totala += $room['capacitate_camera'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($denumire_pachet); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
    <style>
        .package-detail-section {
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .package-detail-title {
            margin-bottom: 15px;
        }
        .package-actions {
            text-align: center;
            margin-top: 10px;
        }
        .package-image img {
            max-height: 200px;
            object-fit: cover;
            border-radius: 5px;
        }
        .actions-container {
            display: flex;
            justify-content: flex-end;
            align-items: flex-start;
            margin-top: 20px;
        }
        .actions-container .package-actions {
            display: flex;
            flex-direction: column;
        }
        .package-detail-container {
            display: flex;
            justify-content: space-between;
        }
        .package-actions button {
            width: 100%;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<?php include("inc/sidebar.php") ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <!-- Secțiune de detalii ale pachetului -->
                <div class="package-detail-section">
                    <h2 class="package-detail-title"><i class="fas fa-info-circle"></i> Detalii <?php echo htmlspecialchars($denumire_pachet); ?></h2>
                    <p><strong>Status:</strong> 
                        <?php
                            if($status == 0){
                                echo "<span class='badge bg-danger'>Nelistat</span>";
                            } else if($status == 1){
                                echo "<span class='badge bg-success'>Listat</span>";
                            }
                        ?>
                    </p>
                    <p><strong>Descriere:</strong> <?php echo htmlspecialchars($descriere); ?></p>
                    <p><strong>Preț:</strong> <?php echo htmlspecialchars($pret); ?> RON</p>
                    <p><strong>Data de început:</strong> <?php echo htmlspecialchars($start_date); ?></p>
                    <p><strong>Data de sfârșit:</strong> <?php echo htmlspecialchars($end_date); ?></p>
                    <p><strong>Capacitate totala:</strong> <?php echo htmlspecialchars($capacitate_totala); ?> persoane</p>

                    
                    <!-- Afișarea imaginii pachetului -->
                    <div class="package-image">
                        <?php if (!empty($imagine)): ?>
                          <p><strong>Imaginea pachetului:</strong>
                            <img src="packege_images/<?php echo htmlspecialchars($imagine); ?>" class="img-fluid" alt="Imagine pentru <?php echo htmlspecialchars($denumire_pachet); ?>">
                        <?php else: ?>
                            <img src="placeholder-image.jpg" class="img-fluid" alt="Nicio imagine disponibilă">
                        <?php endif; ?>
                    </div></p>
                </div>

                <!-- Secțiune de camere asociate -->
                <div class="package-detail-section">
                    <h3 class="package-detail-title"><i class="fas fa-bed"></i> Camere incluse în pachet</h3>
                    <?php if (!empty($rooms)): ?>
                        <ul class="list-group">
                            <?php foreach ($rooms as $room): ?>
                                <li class="list-group-item">
                                    <strong><?php echo htmlspecialchars($room['nume_camera']); ?></strong><br>
                                    Capacitate: <?php echo htmlspecialchars($room['capacitate_camera']); ?> persoane<br>
                                    Preț pe noapte (timpul săptămânii): <?php echo htmlspecialchars($room['pret_saptamana']); ?> RON<br>
                                    Preț pe noapte (weekend): <?php echo htmlspecialchars($room['pret_weekend']); ?> RON
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>Nu există camere asociate acestui pachet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <!-- Secțiune de acțiuni -->
                <div class="package-detail-section">
                    <h4 class="package-detail-title"><i class="fas fa-cogs"></i> Acțiuni</h4>
                    <button class="btn btn-primary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#editPackegeModal?<?php echo $id;?>"><i class="fas fa-edit"></i> Editare pachet</button>
                    <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#deletePackegeModal?<?php echo $id;?>"><i class="fas fa-trash-alt"></i> Ștergere pachet</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("inc/footer.php") ?>

<!-- Modal pentru editarea pachetului -->
<div class="modal fade" id="editPackegeModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="editPackegeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPackegeModalLabel">Editează pachetul</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/packege_edit.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">

                    <div class="mb-3">
                        <label for="edit_denumire_pachet" class="form-label">Denumire Pachet</label>
                        <input type="text" class="form-control" id="edit_denumire_pachet" name="edit_denumire_pachet" value="<?php echo htmlspecialchars($denumire_pachet); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="edit_descriere_pachet" class="form-label">Descriere Pachet</label>
                        <textarea class="form-control" id="edit_descriere_pachet" name="edit_descriere_pachet" rows="3" required><?php echo htmlspecialchars($descriere); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="edit_pret_pachet" class="form-label">Preț Pachet</label>
                        <input type="number" class="form-control" id="edit_pret_pachet" name="edit_pret_pachet" required value="<?php echo htmlspecialchars($pret); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="edit_start_date" class="form-label">Data de început</label>
                        <input type="date" class="form-control" id="edit_start_date" name="edit_start_date" required value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="edit_end_date" class="form-label">Data de sfârșit</label>
                        <input type="date" class="form-control" id="edit_end_date" name="edit_end_date" required value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="edit_imagine_pachet" class="form-label">Schimbă imaginea</label>
                        <input type="file" class="form-control" id="edit_imagine_pachet" name="edit_imagine_pachet" accept="image/*">
                        <!-- Afișarea imaginii curente -->
                        <?php if (!empty($imagine)): ?>
                            <img src="packege_images/<?php echo htmlspecialchars($imagine); ?>" class="img-fluid mt-3" alt="Imagine curentă" style="max-height: 200px; object-fit: cover;">
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="edit_rooms" class="form-label">Camere incluse în pachet</label><br>
                        <span class="form-text text-muted">(Utilizează tasta CTRL pentru a selecta mai multe camere)</span>
                        <select multiple class="form-select" id="edit_rooms" name="edit_rooms[]">
                            <?php
                            // Obținerea tuturor camerelor
                            $rooms_query = "SELECT id, nume_camera FROM rooms";
                            $rooms_stmt = $conn->prepare($rooms_query);
                            $rooms_stmt->execute();
                            $all_rooms = $rooms_stmt->fetchAll(PDO::FETCH_ASSOC);

                            // Obținerea camerelor asociate acestui pachet
                            $packege_rooms_query = "SELECT room_id FROM package_rooms WHERE package_id = ?";
                            $packege_rooms_stmt = $conn->prepare($packege_rooms_query);
                            $packege_rooms_stmt->execute([$id]);
                            $selected_rooms = $packege_rooms_stmt->fetchAll(PDO::FETCH_COLUMN);

                            foreach ($all_rooms as $room) {
                                $selected = in_array($room['id'], $selected_rooms) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($room['id']) . "' $selected>" . htmlspecialchars($room['nume_camera']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="status_check" name="status_check" <?php echo $status == 1 ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="status_check">Listat</label>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="edit_pachet">Salvează modificările</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pentru ștergerea pachetului -->
<div class="modal fade" id="deletePackegeModal?<?php echo $id; ?>" tabindex="-1" aria-labelledby="deletePackegeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deletePackegeModalLabel">Șterge pachetul</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/packege_delete.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <div class="mb-3">
                        <h6>Sunteți sigur că doriți să ștergeți <b><?php echo htmlspecialchars($denumire_pachet); ?></b>?</h6>
                    </div>
                    <button type="submit" class="btn btn-danger" name="sterge_pachet">Da, șterge</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert pentru mesaje -->
<?php
if (isset($_SESSION['message'])) {
    echo "<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
        }
    });
    Toast.fire({
        icon: 'success',
        title: '" . $_SESSION['message'] . "'
    });
    </script>";
    unset($_SESSION['message']); 
}
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
