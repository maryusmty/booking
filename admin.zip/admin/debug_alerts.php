<?php
require 'db.php';
session_start();

$db_username = "mariusmatei754@gmail.com";
$db_password = "administrator";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == $db_username && $password == $db_password) {
        $_SESSION['success'] = "Bine ai venit, $username!";
        header("Location: index.php");  // Schimbă cu pagina unde vrei să redirecționezi
        exit(0);
    } else {
        $_SESSION['error'] = "Te rugam sa incerci din nou!";
        header("Location: debug_alerts.php");  
        exit(0);
    }
}

// Preluarea camerelor din baza de date
$query = "SELECT * FROM rooms";
$stmt = $conn->prepare($query);
$stmt->execute();
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<style>
    .upload-placeholder {
        width: 100%;
        height: 200px;
        background-color: #e9ecef;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        margin-bottom: 10px;
        text-align: center;
    }

    .upload-placeholder input[type="file"] {
        display: none;
    }

    .title-input {
        border: none;
        border-bottom: 1px solid #ced4da;
        width: 100%;
        font-size: 1.25rem;
        margin-bottom: 10px;
    }

    .title-input::placeholder {
        color: #6c757d;
        font-weight: bold;
    }

    .title-input:focus {
        outline: none;
        border-bottom: 1px solid #007bff;
    }

    .status-badge {
        cursor: pointer;
        margin-right: 10px;
    }

    .status-badge.active {
        border: 2px solid #000;
    }
</style>


<div class="container">
    <div class="row">

    <div class='col-sm-3 mb-3'>
            <div class='card'>
                <form action="functions/room_create.php" method="POST" enctype="multipart/form-data">
                    <div class='upload-placeholder' onclick="document.getElementById('roomImages').click();">
                        <span id="uploadText">Apasa pentru a adauga imagini.</span>
                        <input type="file" id="roomImages" name="roomImages[]" multiple required onchange="updateUploadText()">
                    </div>
                    <div class='card-body'>
                        <input type="text" class="title-input" id="roomName" name="roomName" placeholder="Titlu camera" required>
                        
                        <div class="status-options mb-3">
                            <input type="hidden" id="roomStatus" name="roomStatus" value="0">
                            <span id="status-0" class="badge bg-danger status-badge active" onclick="selectStatus(0)">Nelistata</span>
                            <span id="status-1" class="badge bg-success status-badge" onclick="selectStatus(1)">Listata</span>
                            <span id="status-2" class="badge bg-warning text-dark status-badge" onclick="selectStatus(2)">Mentenanta</span>
                        </div>

                        <button type="submit" class="btn btn-sm btn-primary" name="submit_room" style="width: 100%;">Adauga camera</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Card pentru adăugarea unei noi camere -->

        <!-- Afișarea camerelor existente -->
        <?php foreach ($rooms as $room): ?>
            <div class='col-sm-3 mb-3'>
                <div class='card'>
                    <?php 
                    $roomImages = json_decode($room['imagine']);
                    if (is_array($roomImages) && count($roomImages) > 0): ?>
                        <div id="carouselRoom<?php echo $room['id']; ?>" class="carousel slide" data-bs-interval="false">
                            <div class="carousel-inner">
                                <?php foreach ($roomImages as $index => $image): ?>
                                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                        <img src="room_images/<?php echo htmlspecialchars($image); ?>" class="d-block w-100 img-fluid" alt="Imagine camera" style="max-height: 200px; object-fit: cover;">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselRoom<?php echo $room['id']; ?>" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselRoom<?php echo $room['id']; ?>" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    <?php else: ?>
                        <img src="placeholder-image.jpg" class="card-img-top" alt="Nicio imagine disponibilă">
                    <?php endif; ?>
                    <div class='card-body'>
                        <h5 class='card-title'><?php echo htmlspecialchars($room['nume_camera']); ?></h5>
                        <p class='card-text'>
                            Status: 
                            <?php 
                            if ($room['status'] == 0) {
                                echo "<span class='badge bg-danger'>Nelistata</span>";
                            } elseif ($room['status'] == 1) {
                                echo "<span class='badge bg-success'>Listata</span>";
                            } elseif ($room['status'] == 2) {
                                echo "<span class='badge bg-warning text-dark'>Mentenanta</span>";
                            }
                            ?>
                        </p>
                        <a href='roomdetails.php?id=<?php echo $room['id']; ?>' class='btn btn-sm btn-primary' style='width: 100%;'>Vizualizeaza</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function selectStatus(status) {
        document.getElementById('roomStatus').value = status;
        
        // Remove active class from all badges
        document.querySelectorAll('.status-badge').forEach(function(badge) {
            badge.classList.remove('active');
        });
        
        // Add active class to the selected badge
        document.getElementById('status-' + status).classList.add('active');
    }
    function updateUploadText() {
        var input = document.getElementById('roomImages');
        var uploadText = document.getElementById('uploadText');
        var fileCount = input.files.length;

        if (fileCount === 1) {
            uploadText.innerText = "Ai selectat 1 fisier";
        } else if (fileCount > 1) {
            uploadText.innerText = "Ai selectat " + fileCount + " de fisiere";
        } else {
            uploadText.innerText = "Apasa pentru a adauga imagini.";
        }
    }
</script>


</body>
</html>
