
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<?php
// Setarea fusului orar
date_default_timezone_set('Europe/Bucharest');

// Conexiunea la baza de date (presupunem că fișierul db.php se ocupă de conexiune)
require 'db.php';

// Dacă această cerere este pentru evenimente, trimite doar JSON
if (isset($_GET['events'])) {
    // Obține luna și anul curente sau cele din GET
    $month = isset($_GET['month']) ? $_GET['month'] : date('m');
    $year = isset($_GET['year']) ? $_GET['year'] : date('Y');

    // Convertim luna și anul la format numeric pentru a evita problemele
    $month = intval($month);
    $year = intval($year);

    // Obține toate rezervările din baza de date pentru luna curentă din tabelul 'bookings'
    $sql = "SELECT * FROM bookings WHERE MONTH(checkin) = :month AND YEAR(checkin) = :year";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['month' => $month, 'year' => $year]);

    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Alege culoarea în funcție de status
            $color = '#ffc107'; // Default
        if ($row['status'] == 1 || $row['status'] == 2) {
            $color = '#198754'; 
        } elseif ($row['status'] == 3) {
            $color = '#dc3545';
        }
    
        $events[] = [
            'id' => $row['id'],
            'title' => $row['nume_client'],
            'start' => $row['checkin'],
            'end' => $row['checkout'],
            'color' => $color
        ];
    }
    

    // Transmitere JSON și oprirea execuției ulterioare
    header('Content-Type: application/json');
    echo json_encode($events);
    exit; // Asigură că nimic altceva nu este trimis după JSON
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8' />
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css' rel='stylesheet' />
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@5.11.0/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@5.11.0/main.min.js'></script>
    <link rel="stylesheet" href="styles/style.css">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</head>
<style>

#calendar {
            max-width: 900px;
            margin: 0 auto;
        }
</style>
<body>
 <?php include('inc/header.php') ?>
 <?php include('inc/sidebar.php') ?>
 <div class="main-content">
    <div id='calendar'></div>
    </div>


    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="eventModalLabel">Detalii Eveniment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Titlu:</strong> <span id="eventTitle"></span></p>
                <p><strong>Data început:</strong> <span id="eventStart"></span></p>
                <p><strong>Data sfârșit:</strong> <span id="eventEnd"></span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Închide</button>
            </div>
        </div>
    </div>
</div>



    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            editable: true,
            events: function(fetchInfo, successCallback, failureCallback) {
                fetch('http://localhost/rasfatul/admin/calendarphp.php?events=1')
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(event => {
                            let endDate = new Date(event.end);
                            endDate.setDate(endDate.getDate() + 1); 
                            event.end = endDate.toISOString().split('T')[0];
                        });

                        successCallback(data);
                    })
                    .catch(error => {
                        console.error('Error loading events:', error);
                        failureCallback(error);
                    });
            },
            eventClick: function(info) {
                // Setează detaliile evenimentului în modal
                document.getElementById('eventTitle').innerText = info.event.title;
                document.getElementById('eventStart').innerText = info.event.start.toISOString().split('T')[0];
                document.getElementById('eventEnd').innerText = info.event.end.toISOString().split('T')[0];

                // Afișează modalul
                var eventModal = new bootstrap.Modal(document.getElementById('eventModal'));
                eventModal.show();
            },
            eventDrop: function(info) {
                var newStartDate = info.event.startStr;
                var newEndDate = info.event.endStr;
                var eventId = info.event.id;

                fetch('functions/update-event.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id: eventId,
                        start: newStartDate,
                        end: newEndDate,
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert('Rezervarea a fost mutată cu succes!');
                    } else {
                        alert('Eroare la mutarea rezervării.');
                    }
                });
            }
        });

        calendar.render();
});


</script>



</body>
</html>
