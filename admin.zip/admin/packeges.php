<?php 

require 'db.php';

?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<style>
    <style>
    .card-img-top {
    width: 100%;
    height: 200px; /* Înălțimea dorită */
    object-fit: cover; /* Acest lucru va face ca imaginea să se ajusteze la container și să fie decupată dacă este necesar */
}
</style>
</style>
<body>

<?php include("inc/sidebar.php") ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <h2>Pachete</h2>
    <hr>
    
    <div class="row">
        <div class="col-sm-2">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Adauga un nou pachet</h5>
                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addPackageModal" style="width: 100%;"> <i class="fas fa-plus"></i> Adauga</a>
                </div>
            </div>
        </div>
    </div>
        <p></p>

            <?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: '" . $_SESSION['icon'] . "',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
                unset($_SESSION['icon']);
            }
            ?>
            <div class="row">
                <?php 
                    $carduriPePagina = 8;

                    $count_query = "SELECT COUNT(*) as id FROM packeges";
                    $count_query_run = $conn->prepare($count_query);
                    $count_query_run->execute();
                    $count_result = $count_query_run->fetchColumn();
                    
                    $totalCarduri = $count_result;
                    
                    $totalPagini = ceil($totalCarduri / $carduriPePagina);
                    
                    if (!isset ($_GET['pagina']) ) {  
                    $paginaCurenta  = 1;  
                    } else {  
                    $paginaCurenta = $_GET['pagina'];  
                    }  
                    $limita = ($paginaCurenta - 1) * $carduriPePagina;
                    $offset = $carduriPePagina;
                    

                    $query = "SELECT * FROM packeges ORDER BY id DESC LIMIT :limita, :offset";
                    $query_run = $conn->prepare($query);
                    $query_run->bindParam(':limita', $limita, PDO::PARAM_INT);
                    $query_run->bindParam(':offset', $offset, PDO::PARAM_INT);
                    $query_run->execute();

                    // Verificare dacă există pachete
                    if($query_run->rowCount() > 0){
                        while($row = $query_run->fetch()){
                            $id = $row['id'];
                            $denumire_pachet = $row['denumire_pachet'];
                            $descriere = $row['descriere'];
                            $ultima_actualizare = $row['ultima_actualizare'];
                            $status = $row['status'];
                            $pret = $row['pret'];
                ?>

                    <div class='col-sm-3 mb-3'>
                        <div class='card'>
                            <?php if (!empty($row['imagine'])): ?>
                                <img src="packege_images/<?php echo htmlspecialchars($row['imagine']); ?>" class="card-img-top" alt="Imagine pentru <?php echo htmlspecialchars($denumire_pachet); ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <img src="placeholder-image.jpg" class="card-img-top" alt="Nicio imagine disponibilă" style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                            <div class='card-body'>
                                <h5 class='card-title'><?php echo htmlspecialchars($denumire_pachet); ?></h5>
                                <p class='card-text'>
                                    ACTUALIZAT: <?php echo htmlspecialchars($ultima_actualizare); ?><br>
                                    STATUS: 
                                    <?php 
                                    if ($status == 0) {
                                        echo "<span class='badge bg-danger'>Ascuns</span>";
                                    } elseif ($status == 1) {
                                        echo "<span class='badge bg-success'>Publicat</span>";
                                    }
                                    ?>
                                </p>
                                <a href='packegedetails.php?id=<?php echo $id; ?>' class='btn btn-sm btn-primary' style='width: 100%;'>Modifica</a>
                            </div>
                        </div>
                    </div>

                <?php
                        }
                    } else {
                        echo "<div class='col-12'><div class='alert alert-secondary text-center'>Nu există pachete adăugate momentan.</div></div>";
                    }
                ?>
            </div>
         </div>
    </div>

    <?php
echo '<center>';
echo '<nav aria-label="Pagini">';
echo '<ul class="pagination justify-content-center">';
for ($p = 1; $p <= $totalPagini; $p++) {
    // Adaugă clasa "active" pentru pagina curentă
    if ($p == $paginaCurenta) {
        echo '<li class="page-item active" aria-current="page">';
    } else {
        echo '<li class="page-item">';
    }
    echo '<a class="page-link" href="packeges.php?pagina=' . $p . '">' . $p . '</a>';
    echo '</li>';
}
echo '</ul>';
echo '</nav>';
echo '</center>';
?>


        
</div>

<?php include("inc/footer.php") ?>


<!-- Modal pentru adaugarea unui nou pachet -->
<div class="modal fade" id="addPackageModal" tabindex="-1" aria-labelledby="addPackageModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addPackageModalLabel">Adauga un nou pachet</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form action="functions/packege_create.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="denumire_pachet" class="form-label">Denumire Pachet</label>
                <input type="text" class="form-control" id="denumire_pachet" name="denumire_pachet" required>
            </div>
            <div class="mb-3">
                <label for="descriere_pachet" class="form-label">Descriere Pachet</label>
                <textarea class="form-control" id="descriere_pachet" name="descriere_pachet" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="pret_pachet" class="form-label">Pret Pachet</label>
                <input type="number" class="form-control" id="pret_pachet" name="pret_pachet" required>
            </div>
            
            <div class="mb-3">
                <label for="camere_pachet" class="form-label">Selectează Camerele</label><br>
                <span class="form-text text-muted">(Utilizează tasta CTRL pentru a selecta mai multe camere)</span>
                <select class="form-select" id="camere_pachet" name="camere_pachet[]" multiple required>
                    <?php
                    // Preluăm camerele din baza de date
                    $query = "SELECT id, nume_camera FROM rooms WHERE status = 1";
                    $stmt = $conn->prepare($query);
                    $stmt->execute();
                    $camere = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($camere as $camera) {
                        echo '<option value="' . $camera['id'] . '">' . htmlspecialchars($camera['nume_camera']) . '</option>';
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="start_date" class="form-label">Data Început</label>
                <input type="date" class="form-control" id="start_date" name="start_date" required>
            </div>
            <div class="mb-3">
                <label for="end_date" class="form-label">Data Sfârșit</label>
                <input type="date" class="form-control" id="end_date" name="end_date" required>
            </div>

            <div class="mb-3">
                <label for="status_check" class="form-label">Doresti sa publici pachetul?</label>
                <input type="checkbox" class="form-check-input" id="status_check" name="status_check">
                <input type="hidden" id="status_pachet" name="status_pachet" value="0">
            </div>
            <div class="mb-3">
                <label for="imagine_pachet" class="form-label">Imagine Pachet</label>
                <input type="file" class="form-control" id="imagine_pachet" name="imagine_pachet" accept="image/*" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" name="submit_pachet">Adauga Pachet</button>
            </div>
        </form>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="script/main.js"></script>


</body>
</html>
