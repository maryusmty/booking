<?php require 'db.php';?>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

$user_admin_session = $_SESSION['adminLevel'];

if ($user_admin_session == 0) {
    header("Location: index.php");
    exit(0);
}

?>

<?php
$count_query = "SELECT COUNT(*) FROM bookings WHERE status = 1";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_active_bookings = $count_query_run->fetchColumn();


$count_query = "SELECT COUNT(*) FROM bookings WHERE status = 0";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_new_bookings = $count_query_run->fetchColumn();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>

<?php include('inc/sidebar.php') ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <?php
        $sql = 'SELECT * FROM users';
        $stmt = $conn->query($sql);
        $users = $stmt->fetchAll();
    ?>
    <h1>Administreaza Utilizatori</h1>
    
    <div class="row">

        <div class="col-sm-2">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Adauga un utilizator</h5>
                    <a href="#" class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#addUserModal" style="width: 100%;"> <i class="fas fa-plus"></i> Adauga</a>
                </div>
            </div>
        </div>

    </div>
    <?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>
    <?php
    usort($users, function($a, $b) {
        return $b['admin'] - $a['admin'];
    });
    ?>
    

    <p>
                <i class="fa-solid fa-circle-info link-primary"></i> <a href="all_logs.php" class="text-primary">Verifică toate log-urile de pe platformă.</a>
                </p>
    <div class="table-responsive">
    <table class="table table-striped table-hover table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Admin</th>
                <th>Status</th>
                <th>Acțiuni</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): 
                        $user_id = $user['id'];
                        $user_username = $user['username'];
                        $user_email = $user['email'];
                        $user_admin = $user['admin'];
                        $user_status = $user['status'];
                ?>
            <tr>
            <td>
                <a href="profile.php?id=<?php echo $user['id']; ?>">
                    <?php echo htmlspecialchars($user['username']); ?>
                </a>
            </td>
                <td><?php echo htmlspecialchars($user_email); ?></td>
                <td>
                    <?php 
                        if($user_status == 1){
                            echo '<span class="badge bg-success">Online</span>';
                        } else {
                            echo '<span class="badge bg-danger">Offline</span>';
                        }
                    ?>
                </td>
                <td>
                    <?php 
                        if($user_admin == 2){
                            echo '<span class="badge bg-developer">Developer</span>';
                        } else if($user_admin == 1){
                            echo '<span class="badge bg-danger">Administrator</span>';
                        } else {
                            echo '<span class="badge bg-secondary">Not administrator</span>';
                        }
                    ?>
                </td>
                <td>
                    <?php if ($user_admin_session == 2 || ($user_admin_session < 2 && $user_admin < 2)): ?>
                        <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo $user_id; ?>" aria-label="Sterge utilizatorul <?php echo $user_username; ?>"> 
                            <i class="fa fa-trash"></i> Sterge
                        </a>
                        <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editUserModal<?php echo $user_id; ?>" aria-label="Modifica utilizatorul <?php echo $user_username; ?>"> 
                            <i class="fa fa-edit"></i> Modifica
                        </a>
                    <?php else: ?>
                        No actions
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</div>

<?php include('inc/footer.php') ?>


<!-- Modal pentru adaugarea unui utilizator -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
<div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Adauga utilizator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Închide"></button>
            </div>
            <div class="modal-body">
                <form action="functions/users_functions.php" method="POST" enctype="multipart/form-data">
                    <!-- Input ascuns pentru ID-ul camerei -->
                    <input type="hidden" id="roomId" name="id" value="<?php echo $id; ?>">
                    
                    <div class="mb-3">
                        <label for="addUsername" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="addUsername" name="addUsername" required>
                    </div>

                    <div class="mb-3">
                        <label for="addPassword" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="addPassword" name="addPassword" required>
                    </div>

                    <div class="mb-3">
                        <label for="addEmail" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="addEmail" name="addEmail" required>
                    </div>


                    <div class="mb-3">
                    <label for="addAdminLevel" class="form-label">Grad administrare:</label>
                    <select class="form-control" id="addAdminLevel" name="addAdminLevel" required>
                        <option value="-1">--</option>
                        <option value="0">Not administrator</option>
                        <option value="1">Administrator</option>
                        <?php 
                            if($user_admin_session == 2){
                                echo '<option value="2">Developer(ATENTIE!)</option>' ;
                            }
                        ?>
                    </select>
                    </div>
                    
                    
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-dark" name="submit_addUser">Adauga</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- GENERAREA UNICA A FIECARUI MODAL PENTRU STERGERE/EDITARE -->

<?php foreach ($users as $user): 
    $user_id = $user['id'];
    $user_username = $user['username'];
?>

<!-- Modal pentru stergerea unui utilizator -->
<div class="modal fade" id="deleteUserModal<?php echo $user_id; ?>" tabindex="-1" aria-labelledby="deleteUserModalLabel<?php echo $user_id; ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserModalLabel<?php echo $user_id; ?>">Sterge utilizator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/users_functions.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $user_id; ?>">
                    <div class="mb-3">
                        <h6>Sunteti sigur ca doriti sa stergeti utilizatorul: <b><?php echo htmlspecialchars($user_username); ?></b>?</h6>
                    </div>
                    <button type="submit" class="btn btn-danger" name="submit_deleteUser">Da, sterge</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pentru editarea unui utilizator -->
<div class="modal fade" id="editUserModal<?php echo $user_id; ?>" tabindex="-1" aria-labelledby="editUserModalLabel<?php echo $user_id; ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel<?php echo $user_id; ?>">Modifica utilizator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="functions/users_functions.php" method="POST">
                    <input type="hidden" name="id" value="<?php echo $user_id; ?>">
                    
                    <div class="mb-3">
                        <label for="editUsername<?php echo $user_id; ?>" class="form-label">Username:</label>
                        <input type="text" class="form-control" id="editUsername<?php echo $user_id; ?>" name="editUsername" value="<?php echo htmlspecialchars($user_username); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editPassword<?php echo $user_id; ?>" class="form-label">Password:</label>
                        <input type="password" class="form-control" id="editPassword<?php echo $user_id; ?>" placeholder="Lasa acest camp gol daca nu doresti sa schimbi parola." name="editPassword">
                    </div>

                    <div class="mb-3">
                        <label for="editEmail<?php echo $user_id; ?>" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="editEmail<?php echo $user_id; ?>" name="editEmail" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="editAdminLevel<?php echo $user_id; ?>" class="form-label">Grad administrare:</label>
                        <select class="form-control" id="editAdminLevel<?php echo $user_id; ?>" name="editAdminLevel" required>
                            <option value="0" <?php if($user['admin'] == 0) echo 'selected'; ?>>Not administrator</option>
                            <option value="1" <?php if($user['admin'] == 1) echo 'selected'; ?>>Administrator</option>
                            <?php 
                            if($user_admin_session == 2) {
                                echo '<option value="2"';
                                if($user['admin'] == 2) {
                                    echo ' selected';
                                }
                                echo '>Developer(ATENTIE!)</option>';
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" name="submit_editUser">Salveaza modificarile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php endforeach; ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
