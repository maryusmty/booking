<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user_username = $_SESSION['username'];
$user_admin = $_SESSION['adminLevel']; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panou de administrare - Rasfatul Relaxarii</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <button id="toggleSidebar" class="btn btn-sm btn-dark"><i class="fa-solid fa-bars"></i></button>
        <a class="navbar-brand mx-auto" href="#">Rasfatul RelaxSarii</a>
        <div class="dropdown">
            <button class="btn btn-dark dropdown-toggle" type="button" id="userMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user"></i> Bun venit, <?php echo htmlspecialchars($user_username); ?>!
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenuButton">
            <li class="dropdown-header">Functie: 
                        <?php 
                        if($user_admin == 0){
                            echo  '<span class="badge bg-secondary">Not administrator</span>';
                        }elseif ($user_admin == 1) {
                            echo  '<span class="badge bg-danger">Administrator</span>';
                        }elseif ($user_admin == 2) {
                            echo  '<span class="badge bg-developer">Developer</span>';
                        }
                        ?>
                        </li>
                <?php 
                    if ($user_admin >= 1 && $user_admin < 3) {
                        echo '<li><a class="dropdown-item" href="users.php">Administreaza utilizatori</a></li>';
                    }
                ?>
                <li><a class="dropdown-item" href="profile.php">Profil</a></li>
                <li><a class="dropdown-item" href="functions/logout.php">Delogare</a></li>
            </ul>
        </div>
    </div>
</nav>


<script>
document.getElementById('toggleSidebar').addEventListener('click', function() {
    document.body.classList.toggle('sidebar-hidden');
});
</script>
