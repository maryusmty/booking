<?php 
// require "../db.php";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user_admin = $_SESSION['adminLevel'];

$count_query = "SELECT COUNT(*) FROM packeges WHERE status = 1";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_packeges = $count_query_run->fetchColumn();

$count_query = "SELECT COUNT(*) FROM bookings WHERE status = 0";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_bookings = $count_query_run->fetchColumn();

$count_query = "SELECT COUNT(*) FROM rooms WHERE status = 1";
$count_query_run = $conn->prepare($count_query);
$count_query_run->execute();
$count_active_rooms = $count_query_run->fetchColumn();

$count_total_query = "SELECT COUNT(*) FROM rooms";
$count_total_query_run = $conn->prepare($count_total_query);
$count_total_query_run->execute();
$count_total_rooms = $count_total_query_run->fetchColumn();

$query = "SELECT COUNT(*) as total_reviews, AVG(stele_recenzie) as average_rating FROM ratings";
$query_run = $conn->prepare($query);
$query_run->execute();
$result = $query_run->fetch(PDO::FETCH_ASSOC);

$average_rating = round($result['average_rating'], 1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panou de administrare - Rasfatul Relaxarii</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../styles/style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="index.php"><i class="fa-solid fa-house"></i> Acasa</a>
    <a href="packeges.php"><i class="fa-solid fa-box"></i> Pachete 
        <?php 
        if($count_packeges >= 1){
            echo '<span class="badge bg-success">' . htmlspecialchars($count_packeges) . ' active </span>';
        };
        ?> 
    </a>
    <a href="bookings.php"><i class="fa-solid fa-calendar"></i> Rezervari
        <?php 
        if($count_bookings >= 1){
            echo '<span class="badge bg-danger">' . htmlspecialchars($count_bookings) . ' noi </span>';
        };
        ?> 
    </a>
    <a href="rating.php"><i class="fa-solid fa-star"></i> Recenzii <span class="badge bg-warning"><?php echo $average_rating; ?> stele</span></a>
    <a href="rooms.php"><i class="fa-solid fa-door-closed"></i> Camere 
        <?php 
        if($count_total_rooms >= 1){
            echo '<span class="badge bg-success">' . $count_active_rooms . "/" . $count_total_rooms . '</span>';
        };
        ?> 
    </a>
    <?php 
    if ($user_admin == 2) {
        echo'   
         <a href="calendarphp.php"><i class="fa-solid fa-calendar"></i> Calendar</a>
        <a href="#invoiceSubmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
        <i class="fa-solid fa-file-invoice"></i> Facturi
        </a>
        <ul class="collapse list-unstyled" id="invoiceSubmenu">
            <li>
                <a href="manage_invoices.php">
                    <i class="fa-solid fa-folder-open"></i> Facturi emise
                </a>
            </li>
            <li>
                <a href="create_invoice.php">
                    <i class="fa-solid fa-plus-circle"></i> Factura noua
                </a>
            </li>
        </ul>';
    }
    ?>

</div>

