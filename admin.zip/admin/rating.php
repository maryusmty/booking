<?php 
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(0);
}

function add_user_log($conn, $user_id, $action) {
    $log_query = "INSERT INTO user_logs (user_id, action) VALUES (:user_id, :action)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->execute([':user_id' => $user_id, ':action' => $action]);
}
$logged_in_user_id = $_SESSION['user_id'];

// Gestionarea schimbării statusului
if (isset($_POST['toggle_status']) && isset($_POST['id']) && isset($_POST['status'])) {
    $ratingId = $_POST['id'];
    $newStatus = $_POST['status'];

    $query = "UPDATE ratings SET status = :status WHERE id = :id";
    $query_run = $conn->prepare($query);

    $data = [
        ':status' => $newStatus,
        ':id' => $ratingId,
    ];

    if ($query_run->execute($data)) {
        $_SESSION['message'] = "Statusul recenziei a fost actualizat cu succes.";
    } else {
        $_SESSION['message'] = "Eroare la actualizarea statusului.";
    }
    add_user_log($conn, $logged_in_user_id, "UPDATE RATING: A modificat statusul unei recenzii.");
    header('Location: rating.php');
    exit(0);
}

if (isset($_POST['delete_rating']) && isset($_POST['id'])) {
    $ratingId = $_POST['id'];

    $query = "DELETE FROM ratings WHERE id = :id";
    $query_run = $conn->prepare($query);

    $data = [
        ':id' => $ratingId,
    ];

    if ($query_run->execute($data)) {
        $_SESSION['message'] = "Recenzia a fost ștearsă cu succes.";
    } else {
        $_SESSION['message'] = "Eroare la ștergerea recenziei.";
    }

    add_user_log($conn, $logged_in_user_id, "DELETE RATING: A sters o recenzie inregistrata.");
    header('Location: rating.php');
    exit(0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles/style.css">
</head>
<style>
    #starRating .fa-star {
        font-size: 24px;
        color: #ccc;
        cursor: pointer;
    }
    #starRating .fa-star.checked {
        color: #f39c12;
    }
</style>
<body>

<?php include("inc/sidebar.php") ?>
<?php include('inc/header.php') ?>

<div class="main-content">
    <h2>Recenzii</h2>
    <hr>
    <div class="row">
        <div class="col-sm-2">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Adauga o recenzie</h5>
                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addPackageModal" style="width: 100%;"> <i class="fas fa-plus"></i> Adauga</a>
                </div>
            </div>
        </div>
    </div>
    <?php
            if (isset($_SESSION['message'])) {
                echo "<script>
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.onmouseenter = Swal.stopTimer;
                        toast.onmouseleave = Swal.resumeTimer;
                    }
                });
                Toast.fire({
                    icon: 'success',
                    title: '" . $_SESSION['message'] . "'
                });
                </script>";
                unset($_SESSION['message']); 
            }
            ?>
    <div class="row">
    <?php 
        $carduriPePagina = 3;

        $count_query = "SELECT COUNT(*) as id FROM ratings";
        $count_query_run = $conn->prepare($count_query);
        $count_query_run->execute();
        $count_result = $count_query_run->fetchColumn();
        
        $totalCarduri = $count_result;
        
        $totalPagini = ceil($totalCarduri / $carduriPePagina);
        
        if (!isset($_GET['pagina'])) {  
            $paginaCurenta = 1;  
        } else {  
            $paginaCurenta = $_GET['pagina'];  
        }  
        $limita = ($paginaCurenta - 1) * $carduriPePagina;
        $offset = $carduriPePagina;
        

        $query = "SELECT * FROM ratings ORDER BY id DESC LIMIT :limita, :offset";
        $query_run = $conn->prepare($query);
        $query_run->bindParam(':limita', $limita, PDO::PARAM_INT);
        $query_run->bindParam(':offset', $offset, PDO::PARAM_INT);
        $query_run->execute();

        if ($query_run->rowCount() > 0) {
            while ($row = $query_run->fetch()) {
                $id = $row['id'];
                $ratingName = $row['nume_client'];
                $ratingText = $row['text_recenzie'];
                $ratingStars = $row['stele_recenzie'];
                $ratingStatus = $row['status'];

                $stele = '';
                for($i = 1; $i <= 5; $i++) {
                    if($i <= $ratingStars) {
                        $stele .= '<i class="fa-solid fa-star" style="color: #f39c12;"></i> ';
                    } else {
                        $stele .= '<i class="fa-solid fa-star" style="color: #ccc;"></i> ';
                    }
                }
    ?>
    <div class='col-sm-4 mb-3'>
        <div class='card'>
            <div class='card-body'>
                <h5 class='card-title'>Recenzie <?php echo $stele; ?></h5> 
                <p class='card-text'><span class="badge bg-primary"><?php echo $ratingName; ?></span></p>
                <p class="card-text"><?php echo $ratingText; ?></p>
                <span class='pull-right'>
                    <?php if ($ratingStatus == 0): ?>
                        <form action="rating.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="hidden" name="status" value="1">
                            <button type="submit" name="toggle_status" class="btn btn-success" title="Publică">
                                Publica <i class="fa-solid fa-eye" title="Publică"></i>
                            </button>
                        </form>
                    <?php else: ?>
                        <form action="rating.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="hidden" name="status" value="0">
                            <button type="submit" name="toggle_status" class="btn btn-danger" title="Ascunde">
                                Ascunde <i class="fa-solid fa-eye-slash" title="Ascunde"></i>
                            </button>
                        </form>
                    <?php endif; ?>

                    <!-- Formular pentru ștergerea recenziei -->
                    <form action="rating.php" method="POST" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <button type="button" class="btn btn-danger delete-rating-btn" title="Șterge" data-id="<?php echo $id; ?>">
                            <i class="fa fa-trash fa-sm"></i>
                        </button>
                    </form>
                </span>
            </div>
        </div>
    </div>
    <?php
            }
        } else {
            echo "<div class='col-12'><div class='alert alert-secondary text-center'>Nu există recenzii momentan.</div></div>";
        }
    ?>
</div>

    <?php
    echo '<center>';
    echo '<nav aria-label="Pagini">';
    echo '<ul class="pagination justify-content-center">';
    for ($p = 1; $p <= $totalPagini; $p++) {
        if ($p == $paginaCurenta) {
            echo '<li class="page-item active" aria-current="page">';
        } else {
            echo '<li class="page-item">';
        }
        echo '<a class="page-link" href="rating.php?pagina=' . $p . '">' . $p . '</a>';
        echo '</li>';
    }
    echo '</ul>';
    echo '</nav>';
    echo '</center>';
    ?>
</div>

<?php include("inc/footer.php") ?>

<!-- Modal pentru adaugarea unei recenzii noi -->
<div class="modal fade" id="addPackageModal" tabindex="-1" aria-labelledby="addPackageModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addPackageModalLabel">Adauga o recenzie</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="functions/rating_create.php" method="POST">
            <div class="mb-3">
              <label for="rating_clientName" class="form-label">Nume client: </label>
              <input type="text" class="form-control" id="rating_clientName" name="rating_clientName" required>
            </div>
            <div class="mb-3">
              <label for="ratingText" class="form-label">Recenzie: </label>
              <textarea class="form-control" id="ratingText" name="ratingText" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="ratingStars" class="form-label">Stele: </label>
                <div id="starRating">
                    <i class="fa-solid fa-star" data-value="1"></i>
                    <i class="fa-solid fa-star" data-value="2"></i>
                    <i class="fa-solid fa-star" data-value="3"></i>
                    <i class="fa-solid fa-star" data-value="4"></i>
                    <i class="fa-solid fa-star" data-value="5"></i>
                </div>
                <input type="hidden" class="form-control" id="ratingStars" name="ratingStars" required>
            </div>
            <div class="mb-3">
                <label for="status_check_rating" class="form-label">Doresti sa publici recenzia?</label>
                <input type="checkbox" class="form-check-input" id="status_check_rating" name="status_check_rating">
                <input type="hidden" id="ratingStatus" name="ratingStatus" value="0">
            </div>
            <div class="modal-footer">
            <button type="submit" class="btn btn-primary" name="submit_rating">Adauga recenzie</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="script/main.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('#starRating .fa-star');
    const ratingInput = document.getElementById('ratingStars');

    stars.forEach((star, index) => {
        star.addEventListener('mouseover', () => {
            resetStars();
            highlightStars(index + 1);
        });

        star.addEventListener('click', () => {
            ratingInput.value = index + 1;
            highlightStars(index + 1);
        });

        star.addEventListener('mouseout', () => {
            highlightStars(ratingInput.value);
        });
    });

    function resetStars() {
        stars.forEach(star => {
            star.classList.remove('checked');
        });
    }

    function highlightStars(rating) {
        for (let i = 0; i < rating; i++) {
            stars[i].classList.add('checked');
        }
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-rating-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const ratingId = this.getAttribute('data-id');

            Swal.fire({
                title: 'Esti sigur ca doresti sa stergi aceasta recenzie?',
                text: 'Stergerea acesteia este ireversibila.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#555454',
                confirmButtonText: 'Da, șterge!',
                cancelButtonText: 'Anulează'
            }).then((result) => {
                if (result.isConfirmed) {
                    
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'rating.php';

                    const inputId = document.createElement('input');
                    inputId.type = 'hidden';
                    inputId.name = 'id';
                    inputId.value = ratingId;
                    form.appendChild(inputId);

                    const inputDelete = document.createElement('input');
                    inputDelete.type = 'hidden';
                    inputDelete.name = 'delete_rating';
                    inputDelete.value = '1';
                    form.appendChild(inputDelete);

                    document.body.appendChild(form);
                    form.submit();
                }
            });
        });
    });
});

</script>

</body>
</html>
